import java.awt.EventQueue;




import javax.swing.JFrame;
import javax.swing.JTextPane;
import javax.swing.JList;
import javax.swing.JScrollBar;
import javax.swing.JTextArea;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JScrollPane;

import java.util.ArrayList;
import java.awt.List;
import javax.swing.JProgressBar;
import javax.swing.JButton;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JTextField;

import javax.swing.Timer;

public class practise {

	private JFrame frame;
	private ArrayList<String> listOne = new ArrayList<String>();
	private int delay = 1000; 
	private JTextField textField;
	private int num = 0;
	private Timer timer;


	/**
	 * Create the application.
	 */
	public practise() {
		populateList(listOne);
		initialize();
		frame.setVisible(true);
	}
	
	
	/**
	 * cretes list
	 * @return
	 */
	public void populateList(ArrayList<String> listOne) {
		listOne.add("Hi");
		listOne.add("Bye");
		listOne.add("Hehooo");
	}
	

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JTextArea inventory = new JTextArea();
		inventory.setEditable(false);
		inventory.setText("Yo\nyo\nyo\nyo\nyo\nyo\nyo");
		inventory.setBounds(136, 88, 82, 96);
		frame.getContentPane().add(inventory);
		
		JScrollPane scrollPane = new JScrollPane(inventory);
		scrollPane.setBounds(47, 58, 66, 89);
		frame.getContentPane().add(scrollPane);
		
		JButton StartButton = new JButton("Start");
		StartButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				timer.start();
			}
		});
		StartButton.setBounds(160, 102, 117, 29);
		frame.getContentPane().add(StartButton);
		
		textField = new JTextField();
		textField.setEditable(false);
		textField.setBounds(368, 55, 47, 26);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JProgressBar progressBar = new JProgressBar();
		progressBar.setIndeterminate(true);
		progressBar.setBounds(190, 179, 146, 20);
		frame.getContentPane().add(progressBar);
		
		ActionListener countdown = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(Integer.toString(num));
				num += 1;
				if (num == 10) {
					timer.stop();
				}
			}
		};
		timer = new Timer(delay, countdown);
		
		
	
		
		
	}
	
	public static void main(String[] args) {
		practise myPractise = new practise();
		
	}
}
