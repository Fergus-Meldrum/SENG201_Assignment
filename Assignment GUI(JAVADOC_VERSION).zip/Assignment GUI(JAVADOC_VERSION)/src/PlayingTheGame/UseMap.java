package PlayingTheGame;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JTextArea;

import BackGroundClasses.TeamGUI;

import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * Class UseMap
 * 
 * @author Fergus Meldrum, Chang Tu
 *
 */
public class UseMap {

	private JFrame frame;
	GUIGameEnvironment gameManager;
	int cityNum;
	private TeamGUI Team;

	/**
	 * Constructor of UseMap
	 * 
	 * @param manager
	 *            GUIGameEnvironment
	 * @param team
	 *            TeamGUI
	 * @param number
	 *            int
	 */
	public UseMap(GUIGameEnvironment manager, TeamGUI team, int number) {
		gameManager = manager;
		Team = team;
		cityNum = number;
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Finished Window Method
	 */
	public void finishedWindow() {
		gameManager.closeUseMap(this, Team);
	}

	/**
	 * Close Window Method
	 */
	public void closeWindow() {
		frame.dispose();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 330,420);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel lblMapOfThe = new JLabel("Map of the City 0");
		lblMapOfThe.setBounds(31, 40, 282, 39);
		lblMapOfThe.setFont(new Font("Baskerville", Font.BOLD, 32));
		frame.getContentPane().add(lblMapOfThe);

		JLabel label = new JLabel("");
		label.setBounds(115, 63, 95, 120);
		label.setIcon(new ImageIcon(UseMap.class.getResource("/Images/smaller_compassPoints_80.png")));
		frame.getContentPane().add(label);

		JTextArea MapStringBox = new JTextArea();
		MapStringBox.setFont(new Font("Copperplate", Font.PLAIN, 19));
		MapStringBox.setEditable(false);
		MapStringBox.setBounds(2, 2, 178, 94);
		MapStringBox.setText(gameManager.getMapLocations());
		frame.getContentPane().add(MapStringBox);

		JScrollPane scrollPane = new JScrollPane(MapStringBox);
		scrollPane.setBounds(31, 168, 270, 150);
		frame.getContentPane().add(scrollPane);

		JButton btnBack = new JButton("Back");
		frame.getRootPane().setDefaultButton( btnBack );

		btnBack.setBounds(74, 330, 162, 50);
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				finishedWindow();
			}
		});
		btnBack.setFont(new Font("Copperplate", Font.BOLD, 17));
		frame.getContentPane().add(btnBack);
	}
}
