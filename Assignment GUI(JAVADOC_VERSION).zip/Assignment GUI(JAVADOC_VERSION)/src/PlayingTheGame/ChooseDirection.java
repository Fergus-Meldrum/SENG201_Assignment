package PlayingTheGame;

import java.lang.Runnable;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JLabel;

import BackGroundClasses.TeamGUI;

import javax.swing.ImageIcon;

/**
 * ChooseDirection Class to choose the direction
 * 
 * @author Fergus Meldrum, Chang Tu
 *
 */
public class ChooseDirection {

	private JFrame frame;
	private GUIGameEnvironment gameManager;
	private String destination;
	private TeamGUI Team;

	/**
	 * Constructor of ChooseDirection
	 * 
	 * @param manager
	 *            GUIGameEnvironment
	 * @param team
	 *            TeamGUI
	 */
	public ChooseDirection(GUIGameEnvironment manager, TeamGUI team) {
		gameManager = manager;
		Team = team;
		initialize();
		frame.setVisible(true);
	}

	/**
	 * close window method to close the window
	 */
	public void closeWindow() {
		frame.dispose();
	}

	/**
	 * finish window method to finish the window
	 * 
	 * @param destination
	 *            String
	 */
	public void finishedWindow(String destination) {
		gameManager.closeChooseDirection(this, Team, destination);
	}

	/**
	 * Initialize the contents of the ChooseDirection frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("Lucida Grande", Font.BOLD, 16));
		frame.setBounds(100, 100, 430, 340);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JButton btnNorth = new JButton("NORTH");
		btnNorth.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				destination = (gameManager.getLocationList()).get(0);
				finishedWindow(destination);
			}
		});
		btnNorth.setFont(new Font("Silom", Font.BOLD, 17));
		btnNorth.setBounds(175, 121, 81, 51);
		frame.getContentPane().add(btnNorth);

		JButton btnSouth = new JButton("SOUTH");
		btnSouth.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				destination = (gameManager.getLocationList()).get(2);
				finishedWindow(destination);
			}
		});
		btnSouth.setFont(new Font("Silom", Font.BOLD, 17));
		btnSouth.setBounds(175, 227, 81, 51);
		frame.getContentPane().add(btnSouth);

		JButton btnWest = new JButton("WEST");
		btnWest.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				destination = (gameManager.getLocationList()).get(3);
				finishedWindow(destination);
			}
		});
		btnWest.setFont(new Font("Silom", Font.BOLD, 17));
		btnWest.setBounds(95, 174, 81, 51);
		frame.getContentPane().add(btnWest);

		JButton btnEast = new JButton("EAST");
		btnEast.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				destination = (gameManager.getLocationList()).get(1);
				finishedWindow(destination);
			}
		});
		btnEast.setFont(new Font("Silom", Font.BOLD, 17));
		btnEast.setBounds(252, 174, 81, 51);
		frame.getContentPane().add(btnEast);

		JLabel lblWhichDirectionDo = new JLabel("Which direction do you want to choose?");
		lblWhichDirectionDo.setFont(new Font("Silom", Font.BOLD, 14));
		lblWhichDirectionDo.setBounds(57, 86, 308, 16);
		frame.getContentPane().add(lblWhichDirectionDo);

		JLabel lblHeroHomeBase = new JLabel("HOME");
		lblHeroHomeBase.setFont(new Font("Copperplate", Font.BOLD, 17));
		lblHeroHomeBase.setBounds(185, 184, 59, 16);
		frame.getContentPane().add(lblHeroHomeBase);

		JLabel lblBase = new JLabel("BASE");
		lblBase.setFont(new Font("Copperplate", Font.BOLD, 17));
		lblBase.setBounds(195, 199, 59, 16);
		frame.getContentPane().add(lblBase);

		JLabel lblChooseDirection = new JLabel("Choose Direction");
		lblChooseDirection.setFont(new Font("Baskerville", Font.BOLD, 28));
		lblChooseDirection.setBounds(101, 36, 264, 39);
		frame.getContentPane().add(lblChooseDirection);

		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				finishedWindow("backToBase");
			}
		});
		btnBack.setBounds(294, 263, 117, 29);
		frame.getContentPane().add(btnBack);
	}

}
