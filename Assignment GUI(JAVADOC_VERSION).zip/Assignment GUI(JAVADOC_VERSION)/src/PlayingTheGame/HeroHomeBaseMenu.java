package PlayingTheGame;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import java.awt.Font;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTabbedPane;
import javax.swing.SwingConstants;

import BackGroundClasses.TeamGUI;
import BackGroundClasses.Product;
import BackGroundClasses.RandomEvent;

import javax.swing.JTextArea;
import javax.swing.JScrollBar;
import javax.swing.JList;

/**
 * Class HeroHomeBaseMenu
 * 
 * @author Fergus Meldrum, Chang Tu
 *
 */
public class HeroHomeBaseMenu {

	private JFrame frame;
	GUIGameEnvironment gameManager;
	int cityNum;
	private TeamGUI Team;
	private RandomEvent REgenerator;
	private String randomEvent;
	private String notification;
	private String notificationP2;
	private String robbedItem;
	private Product giftedItem;
	private boolean usingMap;
	private boolean choosingDirection;
	private boolean haveRandomEvent;

	/**
	 * Constructor for HeroHomeBaseMenu
	 * 
	 * @param manager
	 *            GUIGameEnvironment
	 * @param team
	 *            TeamGUI
	 * @param number
	 *            int
	 * @param haveRandom
	 *            boolean
	 */
	public HeroHomeBaseMenu(GUIGameEnvironment manager, TeamGUI team, int number, boolean haveRandom) {
		haveRandomEvent = haveRandom;
		gameManager = manager;
		Team = team;
		cityNum = number;

		// testing purposes:
		Product map = new Product("1x Map of City " + gameManager.getCurrentCityNum(), 20);
		Team.addInventory(map);
		Product map2 = new Product("1x Map of City " + gameManager.getCurrentCityNum(), 20);
		Team.addInventory(map2);
		Product map3 = new Product("1x Map of City " + gameManager.getCurrentCityNum(), 20);
		Team.addInventory(map3);

		REgenerator = new RandomEvent(manager);
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Get the notification as a String
	 * 
	 * @return the notification String
	 */
	public String getNotification() {
		randomEvent = REgenerator.getRandomEvent();
		if (randomEvent.equals("Robbed")) {
			if ((Team.getInventory()).size() <= 0) {
				notification = "A citizen walked by";
			} else {
				robbedItem = Team.removeRandomItem();
				notification = "Team has been robbed a "+robbedItem+" by a cat!";
			}
		} else if (randomEvent.equals("Gifted")) {
			giftedItem = REgenerator.getGift();
			Team.addInventory(giftedItem);
			notification = "Team has been gifted a "+giftedItem.getProductName()+"by a local citizen!";
		} else {
			notification = "Nothing to report.";
		}
		return notification;
	}

	/**
	 * Close window method
	 */
	public void closeWindow() {
		frame.dispose();
	}

	/**
	 * Finish Window method
	 * 
	 * @param usingMap
	 *            boolean
	 * @param choosingDirection
	 *            boolean
	 */
	public void finishedWindow(boolean usingMap, boolean choosingDirection) {
		gameManager.closeHeroHomeBaseMenu(this, Team, usingMap, choosingDirection);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("Hero Home Base");
		frame.setBounds(100, 100, 460, 400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel lblWelcomeToCity = new JLabel("Welcome to City " + cityNum);
		lblWelcomeToCity.setBounds(17, 6, 321, 39);
		lblWelcomeToCity.setFont(new Font("Baskerville", Font.BOLD, 28));
		frame.getContentPane().add(lblWelcomeToCity);

		JLabel lblNewLabel = new JLabel("Notifications");
		lblNewLabel.setFont(new Font("Georgia", Font.BOLD, 14));
		lblNewLabel.setBounds(27, 53, 102, 16);
		frame.getContentPane().add(lblNewLabel);

		JLabel REnotification = new JLabel();
		REnotification.setForeground(Color.RED);
		if (haveRandomEvent) {
			REnotification.setText(getNotification());
		} else {
			REnotification.setText("Nothing to report.");
		}
		REnotification.setFont(new Font("Silom", Font.BOLD, 13));
		REnotification.setBounds(27, 82, 427, 16);
		REnotification.setVisible(true);
		frame.getContentPane().add(REnotification);

		JLabel lblInventory_1 = new JLabel("Inventory");
		lblInventory_1.setFont(new Font("Georgia", Font.BOLD, 14));
		lblInventory_1.setBounds(27, 134, 102, 16);
		frame.getContentPane().add(lblInventory_1);

		JTextArea InventoryInfo = new JTextArea();
		InventoryInfo.setFont(new Font("Copperplate", Font.PLAIN, 16));
		InventoryInfo.setEditable(false);
		InventoryInfo.setText(Team.showInventory());
		InventoryInfo.setBounds(270, 153, 57, 16);
		frame.getContentPane().add(InventoryInfo);

		JScrollPane scrollPane = new JScrollPane(InventoryInfo);
		scrollPane.setBounds(27, 162, 216, 126);
		frame.getContentPane().add(scrollPane);

		JButton btnChooseDirection = new JButton("Choose Direction");
		btnChooseDirection.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				finishedWindow(false, true);
			}
		});
		btnChooseDirection.setFont(new Font("Copperplate", Font.BOLD, 17));
		btnChooseDirection.setBounds(255, 162, 162, 50);
		frame.getContentPane().add(btnChooseDirection);

		JLabel lblYouHaveNo = new JLabel("You have no map of city 0!\nOne can be bought at the shop.");
		lblYouHaveNo.setFont(new Font("Silom", Font.BOLD, 14));
		lblYouHaveNo.setBounds(17, 312, 437, 39);
		lblYouHaveNo.setVisible(false);// set to false
		frame.getContentPane().add(lblYouHaveNo);

		JButton btnUsexMap = new JButton("Use Map");
		btnUsexMap.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (Team.hasMap(gameManager.getCurrentCityNum())) {
					usingMap = true;
					finishedWindow(true, false);
				} else {
					lblYouHaveNo.setVisible(true);
				}
			}
		});
		btnUsexMap.setFont(new Font("Copperplate", Font.BOLD, 17));
		btnUsexMap.setBounds(255, 224, 162, 50);
		frame.getContentPane().add(btnUsexMap);

	}
}
