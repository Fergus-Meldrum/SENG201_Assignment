package PlayingTheGame;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JProgressBar;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

import BackGroundClasses.Hero;
import BackGroundClasses.Product;
import BackGroundClasses.TeamGUI;

import java.awt.Font;
import java.util.ArrayList;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.UIManager;
import java.awt.SystemColor;

/**
 * Class hospitalWindow
 * 
 * @author Fergus Meldrum, Chang Tu
 *
 */
public class hospitalWindow {
	private JFrame Hospital;
	TeamGUI Team;
	private GUIGameEnvironment GameManager;
	private int HeroNameIndex;
	private String message;
	private ArrayList<String> heroNameList;
	private Hero currentHero;
	private int index;
	private Timer timer;
	private int count;
	private int delay = 1000;
	private Product Healing;
	private ImageIcon assistentIcon = new ImageIcon(getClass().getResource("/Images/Icon-50-28.png"));


	/**
	 * Construction to the hospitalWindow
	 * 
	 * @param manager
	 *            GUIGameEnvironment
	 * @param team
	 *            TeamGUI
	 */
	public hospitalWindow(GUIGameEnvironment manager, TeamGUI team) {
		GameManager = manager;
		Team = team;
		// testing:
		Product onepack = new Product("Healing", 20);
		Team.addInventory(onepack);

		initialize();
		Hospital.setVisible(true);
	}

	/**
	 * Get the hero name, else "Please select a hero from list"
	 * 
	 * @param index
	 *            as an integer
	 * @return message as String
	 */
	public String getMessage(int index) {
		// method getSelectedIndex returns -1 if nothing selected
		if (index == -1) {
			message = "Please select a hero from list";
		} else {
			heroNameList = Team.getTeamNames();
			message = heroNameList.get(index);
		}
		return message;
	}

	/**
	 * Finished Window Method
	 */
	public void finishedWindow() {
		GameManager.closeHospitalWindow(this, Team);
	}

	/**
	 * Close Window Method
	 */
	public void closeWindow() {
		Hospital.dispose();
	}

	/**
	 * Initialize the contents of the Hospital.
	 */
	private void initialize() {
		Hospital = new JFrame();
		Hospital.getContentPane().setBackground(SystemColor.window);
		Hospital.setBounds(100, 100, 450, 350);
		Hospital.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Hospital.getContentPane().setLayout(null);

		JLabel lblHospital = new JLabel("Hospital");
		lblHospital.setFont(new Font("Baskerville", Font.BOLD, 28));
		lblHospital.setBounds(77, 19, 321, 39);
		Hospital.getContentPane().add(lblHospital);

		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(hospitalWindow.class.getResource("/Images/012-clock.png")));
		label.setBounds(294, 6, 69, 77);
		label.setVisible(false);
		Hospital.getContentPane().add(label);

		// JProgressBar progressBar = new JProgressBar(0, task.getLengthOfTask());
		// progressBar.setBounds(194, 6, 146, 20);
		// Hospital.getContentPane().add(progressBar);

		JLabel lblsHealthIs = new JLabel();
		lblsHealthIs.setForeground(Color.RED);
		lblsHealthIs.setVisible(true);
		lblsHealthIs.setFont(new Font("Copperplate", Font.BOLD, 18));
		lblsHealthIs.setBounds(85, 200, 298, 16);
		Hospital.getContentPane().add(lblsHealthIs);

		JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("Copperplate", Font.BOLD, 14));
		currentHero = Team.getCurrentHero(0);
		// test
		currentHero.setHealth(50);
		lblsHealthIs.setText(currentHero.getHeroName() + "    's Health:         " + currentHero.getHealth() + "%");
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				index = comboBox.getSelectedIndex();
				currentHero = Team.getCurrentHero(index);
				lblsHealthIs.setText(currentHero.getHeroName() + "'s Health: " + currentHero.getHealth() + "%");
			}
		});
		comboBox.setModel(new DefaultComboBoxModel((Team.getTeamNames()).toArray()));
		comboBox.setBounds(128, 127, 131, 33);
		Hospital.getContentPane().add(comboBox);

		JButton btnBack = new JButton("<BACK");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				finishedWindow();
			}
		});
		btnBack.setFont(new Font("Gurmukhi MN", Font.BOLD, 20));
		btnBack.setBounds(330, 279, 95, 39);
		Hospital.getContentPane().add(btnBack);

		JLabel lblPleaseSelectYour = new JLabel("Select the HERO NAME to apply the healing item:");
		lblPleaseSelectYour.setFont(new Font("Silom", Font.BOLD, 14));
		lblPleaseSelectYour.setBounds(42, 86, 365, 16);
		Hospital.getContentPane().add(lblPleaseSelectYour);

		JLabel lblYouHave = new JLabel("You have " + Team.getNumHealings() + "x Healing Items in Iventory");
		lblYouHave.setForeground(Color.BLUE);
		lblYouHave.setFont(new Font("Copperplate", Font.BOLD, 18));
		lblYouHave.setBounds(42, 251, 360, 16);
		Hospital.getContentPane().add(lblYouHave);


		JButton btnApply = new JButton("Apply Healing");
		Hospital.getRootPane().setDefaultButton( btnApply );

		btnApply.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				if (Team.getNumHealings() == 0) {
					JOptionPane.showMessageDialog(btnApply, ("You have no Healing Items to apply!"), message, HeroNameIndex, assistentIcon);
				} else if (currentHero.HealthOneHunnid()) {
					JOptionPane.showMessageDialog(btnApply, (currentHero.getHeroName() + "'s Health is already 100%"), message, HeroNameIndex, assistentIcon);
				} else {
					count = 10;
					Team.removeHealing();
					currentHero.gainHealth();
					lblYouHave.setText("You have " + Team.getNumHealings() + "x Healing Items in Iventory");
					btnApply.setVisible(false);
					timer.start();

				}
			}
		});
		btnApply.setBounds(67, 282, 208, 34);
		btnApply.setFont(new Font("Copperplate", Font.BOLD, 20));
		Hospital.getContentPane().add(btnApply);
		JLabel lblWaitTime = new JLabel("Time left");
		lblWaitTime.setBounds(364, 19, 80, 16);
		lblWaitTime.setFont(new Font("Copperplate", Font.BOLD, 14));

		lblWaitTime.setVisible(false);
		Hospital.getContentPane().add(lblWaitTime);

		JLabel countdown_label = new JLabel("0");
		countdown_label.setForeground(Color.BLUE);
		countdown_label.setBounds(385, 41, 131, 33);
		countdown_label.setFont(new Font("Copperplate", Font.BOLD, 30));
		countdown_label.setVisible(false);
		Hospital.getContentPane().add(countdown_label);
		
		JLabel label_1 = new JLabel("");
		label_1.setIcon(new ImageIcon(hospitalWindow.class.getResource("/Images/Icon-50-28.png")));
		label_1.setBounds(21, 6, 61, 58);
		Hospital.getContentPane().add(label_1);
		
		JLabel label_2 = new JLabel("");
		label_2.setBounds(248, 34, 61, 58);
		Hospital.getContentPane().add(label_2);
		
		JLabel lblSelect = new JLabel("Inventory");
		lblSelect.setFont(new Font("Copperplate", Font.BOLD, 14));
		lblSelect.setBounds(39, 228, 131, 16);
		Hospital.getContentPane().add(lblSelect);
		
		JLabel lblSelectHero = new JLabel("Select Hero");
		lblSelectHero.setFont(new Font("Copperplate", Font.BOLD, 14));
		lblSelectHero.setBounds(42, 114, 104, 16);
		Hospital.getContentPane().add(lblSelectHero);
		
		JLabel lblCurrentHealth = new JLabel("Current health");
		lblCurrentHealth.setFont(new Font("Copperplate", Font.BOLD, 14));
		lblCurrentHealth.setBounds(39, 172, 161, 16);
		Hospital.getContentPane().add(lblCurrentHealth);
		
		JLabel lblSec = new JLabel("sec");
		lblSec.setFont(new Font("Copperplate", Font.PLAIN, 14));
		lblSec.setVisible(false);
		lblSec.setBounds(410, 13, 34, 94);
		Hospital.getContentPane().add(lblSec);

		ActionListener countdown = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				count -= 1;
				//
				label.setVisible(true);
				lblWaitTime.setVisible(true);
				lblSec.setVisible(true);
				countdown_label.setVisible(true);
				btnBack.setVisible(false);

				countdown_label.setText(Integer.toString(count));
				if (count == 0) {
					timer.stop();
					
					label.setVisible(false);
					lblWaitTime.setVisible(false);
					countdown_label.setVisible(false);
					lblSec.setVisible(false);

					
					lblsHealthIs.setText(currentHero.getHeroName() + "'s Health: " + currentHero.getHealth() + "%");
					btnApply.setVisible(true);
					btnBack.setVisible(true);

				}
			}
		};
		timer = new Timer(delay, countdown);

	}
}
