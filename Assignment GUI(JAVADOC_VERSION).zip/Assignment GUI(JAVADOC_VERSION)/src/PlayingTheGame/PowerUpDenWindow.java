package PlayingTheGame;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

import BackGroundClasses.Hero;
import BackGroundClasses.Product;
import BackGroundClasses.TeamGUI;

import java.awt.Font;
import java.util.ArrayList;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * Class PowerUpDenWindow
 * 
 * @author Fergus Meldrum, Chang Tu
 *
 */
public class PowerUpDenWindow {
	private JFrame PowerUpDen;
	TeamGUI Team;
	Hero hero;
	private GUIGameEnvironment GameManager;
	private int HeroNameIndex;
	private String message;
	private ArrayList<String> heroNameList;
	private Product Dice = new Product("1x Dice", 20);
	private Product Guess = new Product("1x Guess", 20);
	private Product SeeTheFuture = new Product("1x SeeTheFuture", 65);
	private String name;
	private Hero currentHero;
	private int index;

	/**
	 * Constructor of PowerUpDenWindow
	 * 
	 * @param manager
	 *            GUIGameEnvironment
	 * @param team
	 *            TeamGUI
	 */
	public PowerUpDenWindow(GUIGameEnvironment manager, TeamGUI team) {

		GameManager = manager;
		Team = team;
		Team.addInventory(Dice);
		Team.addInventory(Dice);
		Team.addInventory(Guess);
		Team.addInventory(Guess);
		Team.addInventory(SeeTheFuture);
		Team.addInventory(SeeTheFuture);
		initialize();
		PowerUpDen.setVisible(true);

	}

	/**
	 * Get the hero name, else "Please select a hero from list"
	 * 
	 * @param index
	 *            as an integer
	 * @return message as String
	 */
	public String getMessage(int index) {
		// method getSelectedIndex returns -1 if nothing selected
		if (index == -1) {
			message = "Please select a hero from list";
		} else {
			heroNameList = Team.getTeamNames();
			message = heroNameList.get(index);
		}
		return message;
	}

	/**
	 * Finished Window Method
	 */
	public void finishedWindow() {
		GameManager.closePowerUpDenWindow(this, Team);
	}

	/**
	 * Close Window Method
	 */
	public void closeWindow() {
		PowerUpDen.dispose();
	}

	/**
	 * Initialize the contents of the PowerUpDen.
	 */
	private void initialize() {
		PowerUpDen = new JFrame();
		PowerUpDen.setBounds(100, 100, 550, 400);
		PowerUpDen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		PowerUpDen.getContentPane().setLayout(null);

		JLabel lblHospital = new JLabel("Power Up Den");
		lblHospital.setFont(new Font("Baskerville", Font.BOLD, 28));
		lblHospital.setBounds(77, 19, 321, 39);
		PowerUpDen.getContentPane().add(lblHospital);

		JTextArea heroInvenTxt = new JTextArea();
		heroInvenTxt.setText("None");
		heroInvenTxt.setBounds(126, 197, 57, 16);
		PowerUpDen.getContentPane().add(heroInvenTxt);

		JLabel lblNewLabel = new JLabel();
		lblNewLabel.setBounds(6, 153, 204, 16);
		PowerUpDen.getContentPane().add(lblNewLabel);

		// needs to be fixed, not working
		JComboBox comboBox = new JComboBox();
		currentHero = Team.getCurrentHero(0);
		lblNewLabel.setText(currentHero.getHeroName() + " applied Power Ups:");
		heroInvenTxt.setText(currentHero.getHeroInventory());
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				index = comboBox.getSelectedIndex();
				currentHero = Team.getCurrentHero(index);
				heroInvenTxt.setText(currentHero.getHeroInventory());
				lblNewLabel.setText(currentHero.getHeroName() + " applied Power Ups:");
			}
		});
		comboBox.setModel(new DefaultComboBoxModel((Team.getTeamNames()).toArray()));
		comboBox.setBounds(45, 113, 131, 33);
		PowerUpDen.getContentPane().add(comboBox);

		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				finishedWindow();
			}
		});
		btnBack.setBounds(408, 325, 117, 29);
		PowerUpDen.getContentPane().add(btnBack);

		JLabel lblPleaseSelectYour = new JLabel("Please select your Hero to aplly Power Up to:");
		lblPleaseSelectYour.setBounds(45, 85, 300, 16);
		PowerUpDen.getContentPane().add(lblPleaseSelectYour);

		JScrollPane scrollPane = new JScrollPane(heroInvenTxt);
		scrollPane.setBounds(6, 181, 170, 191);
		PowerUpDen.getContentPane().add(scrollPane);

		// JProgressBar progressBar = new JProgressBar(0, task.getLengthOfTask());
		// progressBar.setBounds(194, 6, 146, 20);
		// PowerUpDen.getContentPane().add(progressBar);

		// For PowerUp Dice
		JLabel NoDice = new JLabel("NO Dice in your inventory");
		NoDice.setVisible(false);
		NoDice.setBounds(375, 131, 180, 26);
		PowerUpDen.getContentPane().add(NoDice);

		JButton ApplyDice = new JButton("Apply Dice");
		ApplyDice.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Team.removeDice();

				HeroNameIndex = comboBox.getSelectedIndex();
				Team.ApplyPowerUp(getMessage(HeroNameIndex), Dice);
				heroInvenTxt.setText(Team.getHeroInventory(getMessage(HeroNameIndex), Dice));

				if ((Team.getInventory().contains(Dice) == false)) {
					ApplyDice.setVisible(false);
					NoDice.setVisible(true);
				}
			}
		});
		ApplyDice.setVisible(false);

		if (Team.getInventory().contains(Dice)) {
			ApplyDice.setVisible(true);
		}
		ApplyDice.setBounds(252, 131, 117, 29);
		PowerUpDen.getContentPane().add(ApplyDice);

		// For PowerUp Guess
		JLabel NoGuess = new JLabel("NO Guess in your inventory");
		NoGuess.setVisible(false);
		NoGuess.setBounds(308, 169, 154, 16);
		PowerUpDen.getContentPane().add(NoGuess);

		JButton ApplyGuess = new JButton("Apply Guess");
		ApplyGuess.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Team.removeGuess();

				HeroNameIndex = comboBox.getSelectedIndex();
				Team.ApplyPowerUp(getMessage(HeroNameIndex), Guess);
				heroInvenTxt.setText(Team.getHeroInventory(getMessage(HeroNameIndex), Guess));
				if ((Team.getInventory().contains(Guess) == false)) {
					ApplyGuess.setVisible(false);
					NoGuess.setVisible(true);
				}
			}
		});
		ApplyGuess.setVisible(false);

		if (Team.getInventory().contains(Guess)) {
			ApplyGuess.setVisible(true);
		}
		ApplyGuess.setBounds(250, 169, 154, 16);
		PowerUpDen.getContentPane().add(ApplyGuess);

		// For PowerUp SeeFuture
		JLabel NoSeeFuture = new JLabel("NO See the Future in your inventory");
		NoSeeFuture.setVisible(false);
		NoSeeFuture.setBounds(304, 197, 169, 16);
		PowerUpDen.getContentPane().add(NoSeeFuture);

		JButton ApplySeeFuture = new JButton("Apply See the Future");
		ApplySeeFuture.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Team.removeSeeTheFuture();
				HeroNameIndex = comboBox.getSelectedIndex();
				name = getMessage(HeroNameIndex);
				Team.ApplyPowerUp(name, SeeTheFuture); // apply the power up

				heroInvenTxt.setText(Team.getHeroInventory(name, SeeTheFuture)); // set the name
				if ((Team.getInventory().contains(SeeTheFuture) == false)) {
					ApplySeeFuture.setVisible(false);
					NoSeeFuture.setVisible(true);
				}
			}
		});
		ApplySeeFuture.setVisible(false);

		if (Team.getInventory().contains(SeeTheFuture)) {
			ApplySeeFuture.setVisible(true);
		}
		ApplySeeFuture.setBounds(252, 214, 166, 16);
		PowerUpDen.getContentPane().add(ApplySeeFuture);

	}
}
