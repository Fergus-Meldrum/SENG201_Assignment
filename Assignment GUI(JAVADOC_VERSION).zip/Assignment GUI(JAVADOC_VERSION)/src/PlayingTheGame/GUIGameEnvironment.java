package PlayingTheGame;

import java.util.ArrayList;

import java.util.Collections;

import BackGroundClasses.TeamGUI;
import Shop.PowerUpWindow;
import Shop.ShopWindow;
import StartingGame.Initialization;
import StartingGame.SetHero;
import Shop.PurchaseDiceWindow;
import Shop.PurchaseGuessWindow;
import Shop.PurchaseHealingWindow;
import Shop.PurchaseSeeTheFutureWindow;
import Shop.PurchaseMapWindow;

/**
 * GUIGameEnvironment Runner
 * 
 * @author Fergus Meldrum, Chang Tu
 *
 */
public class GUIGameEnvironment {

	private int NumCities;
	private int heroNumber = 1;
	// need to update city number each time willian is defeated
	private int cityNumber = 1;
	private ArrayList<String> locationList = new ArrayList<String>();

	/**
	 * Initialize the GUIGameEnvironment
	 */
	public GUIGameEnvironment() {
		locationList.add("Hospital");
		locationList.add("Shop");
		locationList.add("PowerUp Den");
		locationList.add("Villians Lair");
	}

	/**
	 * Returns the lacation list
	 * 
	 * @return locationList ArrayList
	 */
	public ArrayList<String> getLocationList() {
		return locationList;
	}

	/**
	 * Shuffle the location list
	 * 
	 * @return locationList as an ArrayList<String>
	 */
	public ArrayList<String> shuffleLocations() {
		Collections.shuffle(locationList);
		return locationList;
	}

	/**
	 * Returns the Map location
	 * 
	 * @return Map location as a String
	 */
	public String getMapLocations() {
		return "Map Directions:" + "\nNorth : " + locationList.get(0) + "\nEast : " + locationList.get(1) + "\nSouth : "
				+ locationList.get(2) + "\nWest : " + locationList.get(3);
	}

	/**
	 * Get the number of current city
	 * 
	 * @return cityNumber as integer
	 */
	public int getCurrentCityNum() {
		return cityNumber;
	}

	/**
	 * Set the number of cities by the user
	 * 
	 * @param number
	 *            type int
	 */
	public void setNumCities(int number) {
		NumCities = number;
	}

	/**
	 * Get the number of city cose by the user, return the number of city
	 * 
	 * @return NumCities int
	 */
	public int getNumCities() {
		return NumCities;
	}

	/**
	 * Lauch the setup screen
	 * 
	 * @param Team
	 *            type TeamGUI
	 */
	public void launchSetUpScreen(TeamGUI Team) {
		Initialization letsGo = new Initialization(this, Team);
	}

	/**
	 * Close the setup screen
	 * 
	 * @param setUpScreen
	 *            of type Initialization
	 * @param Team
	 *            of type TeamGUI
	 */
	public void closeSetUpScreen(Initialization setUpScreen, TeamGUI Team) {
		setUpScreen.closeWindow();
		launchSetHero(Team, heroNumber);
	}

	/**
	 * 
	 * @param Team
	 * @param heroNumber
	 */
	public void launchSetHero(TeamGUI Team, int heroNumber) {
		SetHero hero = new SetHero(this, Team, heroNumber);
	}

	/**
	 * Lauch the set hero screen
	 * 
	 * @param setHeroScreen
	 *            of type SetHero
	 * @param Team
	 *            of type TeamGUI
	 */
	public void closeSetHero(SetHero setHeroScreen, TeamGUI Team) {
		setHeroScreen.closeWindow();
		heroNumber += 1;
		if (heroNumber <= Team.getNumHeros()) {
			launchSetHero(Team, heroNumber);
		} else {
			//launchHeroHomeBaseMenu(Team, true);
			 launchHosital(Team);
			// launchPowerUpDenWindow(Team);
		}
	}

	/**
	 * Lauch the Hero Home Base Menu
	 * 
	 * @param Team
	 *            TeamGUI
	 * @param haveRandomEvent
	 *            boolean
	 */
	public void launchHeroHomeBaseMenu(TeamGUI Team, boolean haveRandomEvent) {
		HeroHomeBaseMenu HeroHomeBaseMenu = new HeroHomeBaseMenu(this, Team, cityNumber, haveRandomEvent);
	}

	/**
	 * Close the HeroHomeBaseMenu
	 * 
	 * @param window
	 *            HeroHomeBaseMenu
	 * @param Team
	 *            TeamGUI
	 * @param usingMap
	 *            boolean
	 * @param choosingDirection
	 *            boolean
	 */
	public void closeHeroHomeBaseMenu(HeroHomeBaseMenu window, TeamGUI Team, boolean usingMap,
			boolean choosingDirection) {
		window.closeWindow();
		if (usingMap) {
			launchUseMap(Team);
		} else if (choosingDirection) {
			launchChooseDirection(Team);
		} else {
			System.out.println("Error with close Hero home Base function");
		}
	}

	/**
	 * Lauch the Hospital window
	 * 
	 * @param Team
	 *            TeamGUI
	 */
	public void launchHosital(TeamGUI Team) {
		hospitalWindow hospital = new hospitalWindow(this, Team);
	}

	/**
	 * Close the Hospital window
	 * 
	 * @param window
	 *            hospitalWindow
	 * @param Team
	 *            TeamGUI
	 */
	public void closeHospitalWindow(hospitalWindow window, TeamGUI Team) {
		window.closeWindow();
		launchHeroHomeBaseMenu(Team, true);
	}

	/**
	 * Lauch the use map window
	 * 
	 * @param Team
	 *            TeamGUI
	 */
	public void launchUseMap(TeamGUI Team) {
		UseMap map = new UseMap(this, Team, cityNumber);
	}

	/**
	 * Close the use map window
	 * 
	 * @param window
	 *            UseMap
	 * @param Team
	 *            TeamGUI
	 */
	public void closeUseMap(UseMap window, TeamGUI Team) {
		window.closeWindow();
		launchHeroHomeBaseMenu(Team, false);
	}

	/**
	 * Lauch Choose Direction window
	 * 
	 * @param Team
	 *            TeamGUI
	 */
	public void launchChooseDirection(TeamGUI Team) {
		ChooseDirection ChooseDirection = new ChooseDirection(this, Team);
	}

	/**
	 * Close Choose Direction window
	 * 
	 * @param window
	 *            ChooseDirection
	 * @param Team
	 *            TeamGUI
	 * @param destination
	 *            String
	 */
	public void closeChooseDirection(ChooseDirection window, TeamGUI Team, String destination) {
		window.closeWindow();
		if (destination.equals("Hospital")) {
			System.out.println("you choose hospital");
			launchHosital(Team);
		} else if (destination.equals("Shop")) {
			System.out.println("you choose Shop!");
			launchShop(Team);
		} else if (destination.equals("PowerUp Den")) {
			System.out.println("you choose Power Up den");
			launchPowerUpDenWindow(Team);
		} else if (destination.equals("Villians Lair")) {
			System.out.println("you choose Villians Lair");
			// launchVilliansLair
		} else if (destination.equals("backToBase")) {
			launchHeroHomeBaseMenu(Team, false);
		} else {
			System.out.println("There is a problem with enterDestination method");
		}
	}

	/**
	 * Lauch shop
	 * 
	 * @param team
	 *            TeamGUI
	 */
	public void launchShop(TeamGUI team) {
		ShopWindow ShopWindow = new ShopWindow(this, team);
	}

	/**
	 * Close shop
	 * 
	 * @param window
	 *            ShopWindow
	 * @param destination
	 *            String
	 * @param Team
	 *            TeamGUI
	 */
	public void closeShop(ShopWindow window, String destination, TeamGUI Team) {
		window.closeWindow();
		if (destination == "PowerUps") {
			launchPowerUp(this, Team);
		} else if (destination == "Healings") {
			launchHealing(this, Team);

		} else if (destination == "Maps") {
			launchMap(this, Team);

		} else if (destination == "HeroHomeBase") {
			launchHeroHomeBaseMenu(Team, true);

		}

	}

	/**
	 * Lauch PowerUp window
	 * 
	 * @param gameManager
	 *            GUIGameEnvironment
	 * @param team
	 *            TeamGUI
	 */
	public void launchPowerUp(GUIGameEnvironment gameManager, TeamGUI team) {
		PowerUpWindow PowerUpWindow = new PowerUpWindow(this, team);
	}

	/**
	 * Close PowerUp window
	 * 
	 * @param product
	 *            String
	 * @param window
	 *            PowerUpWindow
	 * @param team
	 *            TeamGUI
	 */
	public void closePowerUp(String product, PowerUpWindow window, TeamGUI team) {
		window.closeWindow();
		if (product.equals("Dice")) {
			launchPurchaseDice(team);
		} else if (product.equals("Guess")) {
			launchPurchaseGuess(team);
		} else if (product.equals("SeeTheFuture")) {
			launchPurchaseSeeFuture(team);
		} else if (product.equals("ShopMainMenu")) {
			launchShop(team);
		}

	}

	/**
	 * Lauch PurchaseDice window
	 * 
	 * @param Team
	 *            TeamGUI
	 */
	public void launchPurchaseDice(TeamGUI Team) {

		PurchaseDiceWindow PurchaseDiceWindow = new PurchaseDiceWindow(this, Team);
	}

	/**
	 * Close PurchaseDice window
	 * 
	 * @param window
	 *            PurchaseDiceWindow
	 */
	public void closePurchaseDice(PurchaseDiceWindow window) {
		window.closeWindow();
	}

	/**
	 * Lauch PurchaseGuess window
	 * 
	 * @param Team
	 *            TeamGUI
	 */
	public void launchPurchaseGuess(TeamGUI Team) {
		PurchaseGuessWindow PurchaseGuessWindow = new PurchaseGuessWindow(this, Team);
	}

	/**
	 * Close PurchaseGuess window
	 * 
	 * @param window
	 *            PurchaseGuessWindow
	 */
	public void closePurchaseGuess(PurchaseGuessWindow window) {
		window.closeWindow();
	}

	/**
	 * Lauch PurchaseSeeFuture window
	 * 
	 * @param Team
	 *            TeamGUI
	 */
	public void launchPurchaseSeeFuture(TeamGUI Team) {
		PurchaseSeeTheFutureWindow PurchaseSeeTheFutureWindow = new PurchaseSeeTheFutureWindow(this, Team);
	}

	/**
	 * Close PurchaseSeeFuture window
	 * 
	 * @param window
	 *            PurchaseSeeTheFutureWindow
	 */
	public void closePurchaseSeeFuture(PurchaseSeeTheFutureWindow window) {
		window.closeWindow();
	}

	/**
	 * launch Healing window
	 * 
	 * @param gameManager
	 *            GUIGameEnvironment
	 * @param team
	 *            TeamGUI
	 */
	public void launchHealing(GUIGameEnvironment gameManager, TeamGUI team) {
		PurchaseHealingWindow PurchaseHealingWindow = new PurchaseHealingWindow(this, team);
	}

	/**
	 * close Healing window
	 * 
	 * @param window
	 *            PurchaseHealingWindow
	 * @param team
	 *            TeamGUI
	 */
	public void closeHealing(PurchaseHealingWindow window, TeamGUI team) {
		window.closeWindow();
		launchShop(team);

	}

	/**
	 * launch Map window
	 * 
	 * @param gameManager
	 *            GUIGameEnvironment
	 * @param team
	 *            TeamGUI
	 */
	public void launchMap(GUIGameEnvironment gameManager, TeamGUI team) {
		PurchaseMapWindow PurchaseMapWindow = new PurchaseMapWindow(this, team);
	}

	/**
	 * close Map window
	 * 
	 * @param window
	 *            PurchaseMapWindow
	 * @param team
	 *            TeamGUI
	 */
	public void closeMap(PurchaseMapWindow window, TeamGUI team) {
		window.closeWindow();
		launchShop(team);

	}

	/**
	 * launch PowerUp Den Window
	 * 
	 * @param Team
	 *            TeamGUI
	 */
	public void launchPowerUpDenWindow(TeamGUI Team) {
		PowerUpDenWindow PowerUpDenWindow = new PowerUpDenWindow(this, Team);
	}

	/**
	 * close PowerUp Den Window
	 * 
	 * @param window
	 *            PowerUpDenWindow
	 * @param Team
	 *            TeamGUI
	 */
	public void closePowerUpDenWindow(PowerUpDenWindow window, TeamGUI Team) {
		window.closeWindow();
		launchHeroHomeBaseMenu(Team, true);
	}

	/**
	 * Main method to run the game
	 * 
	 * @param args
	 *            String[]
	 */
	public static void main(String[] args) {
		GUIGameEnvironment Game = new GUIGameEnvironment();
		TeamGUI OurTeam = new TeamGUI();
		Game.launchSetUpScreen(OurTeam);
	}

}
