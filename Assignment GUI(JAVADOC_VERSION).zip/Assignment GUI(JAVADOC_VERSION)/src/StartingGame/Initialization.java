package StartingGame;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;

import BackGroundClasses.TeamGUI;
import PlayingTheGame.GUIGameEnvironment;

import javax.swing.JSlider;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

/**
 * @author Fergus Meldrum, Chang Tu
 */
public class Initialization {

	private JFrame GameSetup;
	private JTextField TeamNameInput;
	private GUIGameEnvironment gameManager;
	private TeamGUI Team;
	private ImageIcon assistentIcon = new ImageIcon(getClass().getResource("/Images/003-squares.png"));


	/**
	 * 
	 * @param GameEnvironment
	 * @param team
	 */
	public Initialization(GUIGameEnvironment GameEnvironment, TeamGUI team) {
		gameManager = GameEnvironment;
		gameManager.shuffleLocations();
		Team = team;
		initialize();
		GameSetup.setVisible(true);
	}

	/**
	 * 
	 */
	public void finishedWindow() {
		gameManager.closeSetUpScreen(this, Team);
	}

	/**
	 * 
	 */
	public void closeWindow() {
		GameSetup.dispose();
	}

	/**
	 * Initialize the contents of the Game.
	 */
	private void initialize() {
		GameSetup = new JFrame();
		GameSetup.setTitle("Game Setup");
		GameSetup.setBounds(100, 100, 450, 330);
		GameSetup.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		GameSetup.getContentPane().setLayout(null);

		JLabel lblSetupYourGame = new JLabel("Game SetUp");
		lblSetupYourGame.setFont(new Font("Baskerville", Font.BOLD, 32));
		lblSetupYourGame.setBounds(77, 38, 321, 39);
		GameSetup.getContentPane().add(lblSetupYourGame);

		JLabel lblWelcome = new JLabel("");
		lblWelcome.setIcon(new ImageIcon(Initialization.class.getResource("/Images/003-squares.png")));
		lblWelcome.setFont(new Font("Baskerville", Font.BOLD, 28));
		lblWelcome.setBounds(6, -15, 139, 95);
		GameSetup.getContentPane().add(lblWelcome);

		JLabel lblNewLabel = new JLabel("Enter a TEAM NAME ");
		lblNewLabel.setFont(new Font("Silom", Font.PLAIN, 14));
		lblNewLabel.setBounds(26, 89, 213, 16);
		GameSetup.getContentPane().add(lblNewLabel);

		TeamNameInput = new JTextField();
		TeamNameInput.setFont(new Font("Copperplate", Font.PLAIN, 20));
		TeamNameInput.setBounds(127, 130, 130, 26);
		GameSetup.getContentPane().add(TeamNameInput);
		TeamNameInput.setColumns(10);

		JLabel lblTeamName = new JLabel("TEAM NAME");
		lblTeamName.setFont(new Font("Copperplate", Font.PLAIN, 14));
		lblTeamName.setBounds(26, 134, 344, 16);
		GameSetup.getContentPane().add(lblTeamName);

		JLabel lblHowManyCities = new JLabel("How many CITIES and HEROES would you like to have?");
		lblHowManyCities.setFont(new Font("Silom", Font.PLAIN, 14));
		lblHowManyCities.setBounds(26, 168, 405, 16);
		GameSetup.getContentPane().add(lblHowManyCities);

		JSlider NumCitiesSlider = new JSlider();
		NumCitiesSlider.setValue(10);
		NumCitiesSlider.setSnapToTicks(true);
		NumCitiesSlider.setPaintLabels(true);
		NumCitiesSlider.setMinorTickSpacing(1);
		NumCitiesSlider.setMinimum(3);
		NumCitiesSlider.setMaximum(6);
		NumCitiesSlider.setMajorTickSpacing(1);
		NumCitiesSlider.setFont(new Font("Lucida Grande", Font.BOLD, 7));
		NumCitiesSlider.setBounds(139, 196, 83, 44);
		GameSetup.getContentPane().add(NumCitiesSlider);

		JLabel lblCityNumber = new JLabel("CITY NUMBER");
		lblCityNumber.setFont(new Font("Copperplate", Font.PLAIN, 14));
		lblCityNumber.setBounds(26, 207, 113, 16);
		GameSetup.getContentPane().add(lblCityNumber);

		JLabel lblHeroNumber = new JLabel("HERO NUMBER");
		lblHeroNumber.setFont(new Font("Copperplate", Font.PLAIN, 14));
		lblHeroNumber.setBounds(234, 207, 113, 16);
		GameSetup.getContentPane().add(lblHeroNumber);

		JSlider NumHerosSlider = new JSlider();
		NumHerosSlider.setMajorTickSpacing(1);
		NumHerosSlider.setValue(10);
		NumHerosSlider.setSnapToTicks(true);
		NumHerosSlider.setPaintLabels(true);
		NumHerosSlider.setMinimum(1);
		NumHerosSlider.setMaximum(3);
		NumHerosSlider.setFont(new Font("Lucida Grande", Font.BOLD, 7));
		NumHerosSlider.setBounds(347, 196, 63, 44);
		GameSetup.getContentPane().add(NumHerosSlider);


		JButton button = new JButton("START NEW GAME");
		GameSetup.getRootPane().setDefaultButton( button );

		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (Team.nameFine(TeamNameInput.getText())) {
					Team.setTeamName(TeamNameInput.getText());
					gameManager.setNumCities(NumCitiesSlider.getValue());
					Team.setNumHeros(NumHerosSlider.getValue());
					finishedWindow();
				} else {
					JOptionPane.showMessageDialog(button, ("Team name must be between 2 and 10 characters long!"), null, 0, assistentIcon);

				}
			}
		});
		button.setFont(new Font("Gurmukhi MN", Font.BOLD, 17));
		button.setBounds(97, 241, 250, 50);
		GameSetup.getContentPane().add(button);

		JLabel lblNewLabel_1 = new JLabel("(between 2 and 10 characters long) ");
		lblNewLabel_1.setForeground(Color.GRAY);
		lblNewLabel_1.setFont(new Font("Silom", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(26, 106, 298, 16);
		GameSetup.getContentPane().add(lblNewLabel_1);

	}
}
