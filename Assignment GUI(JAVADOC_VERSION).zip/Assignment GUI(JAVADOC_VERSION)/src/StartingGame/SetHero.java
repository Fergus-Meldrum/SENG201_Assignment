package StartingGame;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.lang.Runnable;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;

import BackGroundClasses.Hero;
import BackGroundClasses.TeamGUI;
import PlayingTheGame.GUIGameEnvironment;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

/**
 * 
 * @author Fergus Meldrum, Chang Tu
 *
 */
public class SetHero {

	private JFrame SetHero;
	private JTextField enterHeroName;
	private GUIGameEnvironment gameManager;
	private TeamGUI Team;
	private int heroNum;
	private Hero Hero = new Hero();
	private ImageIcon assistentIcon = new ImageIcon(getClass().getResource("/Images/003-squares.png"));

	/**
	 * 
	 * @param GameEnvironment
	 * @param team
	 * @param number
	 */
	public SetHero(GUIGameEnvironment GameEnvironment, TeamGUI team, int number) {
		gameManager = GameEnvironment;
		Team = team;
		heroNum = number;
		initialize();
		SetHero.setVisible(true);
	}

	/**
	 * 
	 */
	public void finishedWindow() {
		gameManager.closeSetHero(this, Team);
	}

	/**
	 * 
	 */
	public void closeWindow() {
		SetHero.dispose();
	}

	/**
	 * Initialize the contents of the SetHero.
	 */
	private void initialize() {
		SetHero = new JFrame();
		SetHero.setBounds(100, 100, 450, 530);
		SetHero.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		SetHero.getContentPane().setLayout(null);

		JLabel lblChooseAName = new JLabel("Click hero type button to select a TYPE for hero:");
		lblChooseAName.setFont(new Font("Silom", Font.BOLD, 14));
		lblChooseAName.setBounds(31, 85, 367, 16);
		SetHero.getContentPane().add(lblChooseAName);

		JLabel lblChooseHeroName = new JLabel("Create Hero " + heroNum);
		lblChooseHeroName.setFont(new Font("Baskerville", Font.BOLD, 28));
		lblChooseHeroName.setBounds(31, 12, 321, 39);
		SetHero.getContentPane().add(lblChooseHeroName);



		JButton btnNext = new JButton("Next>");
		SetHero.getRootPane().setDefaultButton( btnNext );

		btnNext.setVisible(false);
		btnNext.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (Team.sameName(enterHeroName.getText())) {
					JOptionPane.showMessageDialog(btnNext, "Heros may not have the same name!\n Please choose another name.", null, heroNum, assistentIcon);
				} else {
					Hero.setName(enterHeroName.getText());
					Team.addHero(Hero);
					finishedWindow();
				}
			}
		});
		btnNext.setFont(new Font("Gurmukhi MN", Font.BOLD, 17));
		btnNext.setBounds(295, 449, 136, 50);
		SetHero.getContentPane().add(btnNext);

		JButton button = new JButton("LeBron");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Hero.setType("LeBron");
				btnNext.setVisible(true);
			}
		});
		button.setFont(new Font("Silom", Font.PLAIN, 15));
		button.setBounds(317, 135, 81, 51);
		SetHero.getContentPane().add(button);

		JButton button_1 = new JButton("Messi");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Hero.setType("Messi");
				btnNext.setVisible(true);
			}
		});
		button_1.setFont(new Font("Silom", Font.PLAIN, 15));
		button_1.setBounds(317, 186, 81, 51);
		SetHero.getContentPane().add(button_1);

		JButton button_2 = new JButton("Federer");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Hero.setType("Federer");
				btnNext.setVisible(true);
			}
		});
		button_2.setFont(new Font("Silom", Font.PLAIN, 15));
		button_2.setBounds(317, 235, 81, 51);
		SetHero.getContentPane().add(button_2);

		JButton button_3 = new JButton("Serena");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Hero.setType("Serena");
				btnNext.setVisible(true);
			}
		});
		button_3.setFont(new Font("Silom", Font.PLAIN, 15));
		button_3.setBounds(317, 285, 81, 51);
		SetHero.getContentPane().add(button_3);

		JButton button_4 = new JButton("Brady");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Hero.setType("Brady");
				btnNext.setVisible(true);
			}
		});
		button_4.setFont(new Font("Silom", Font.PLAIN, 15));
		button_4.setBounds(317, 335, 81, 51);
		SetHero.getContentPane().add(button_4);

		JButton button_5 = new JButton("Barret");
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Hero.setType("Barret");
				btnNext.setVisible(true);
			}
		});
		button_5.setFont(new Font("Silom", Font.PLAIN, 15));
		button_5.setBounds(317, 386, 81, 51);
		SetHero.getContentPane().add(button_5);

		JLabel lblNewLabel = new JLabel("HERO TYPE");
		lblNewLabel.setForeground(Color.RED);
		lblNewLabel.setFont(new Font("Silom", Font.PLAIN, 16));
		lblNewLabel.setBounds(317, 113, 100, 29);
		SetHero.getContentPane().add(lblNewLabel);

		JLabel lblSpecialAbilities = new JLabel("SPECIAL ABILITIES");
		lblSpecialAbilities.setForeground(Color.BLUE);
		lblSpecialAbilities.setBackground(Color.BLACK);
		lblSpecialAbilities.setFont(new Font("Silom", Font.PLAIN, 16));
		lblSpecialAbilities.setBounds(31, 113, 173, 29);
		SetHero.getContentPane().add(lblSpecialAbilities);

		JLabel lblNewLabel_1 = new JLabel("Fast recovery rate while healing");
		lblNewLabel_1.setFont(new Font("Georgia", Font.PLAIN, 13));
		lblNewLabel_1.setBounds(31, 151, 213, 16);
		SetHero.getContentPane().add(lblNewLabel_1);

		JLabel label = new JLabel("Takes less damage after losing to villian");
		label.setFont(new Font("Georgia", Font.PLAIN, 13));
		label.setBounds(31, 202, 260, 16);
		SetHero.getContentPane().add(label);

		JLabel label_1 = new JLabel("Always know the direction, no need to buy maps");
		label_1.setFont(new Font("Georgia", Font.PLAIN, 13));
		label_1.setBounds(31, 251, 283, 16);
		SetHero.getContentPane().add(label_1);

		JLabel label_2 = new JLabel("Extra roll when playing dice game");
		label_2.setFont(new Font("Georgia", Font.PLAIN, 13));
		label_2.setBounds(31, 301, 236, 16);
		SetHero.getContentPane().add(label_2);

		JLabel label_3 = new JLabel("Gets better prices on products at the store");
		label_3.setFont(new Font("Georgia", Font.PLAIN, 13));
		label_3.setBounds(31, 351, 283, 16);
		SetHero.getContentPane().add(label_3);

		JLabel label_4 = new JLabel("Extra guess when playing guess the number");
		label_4.setFont(new Font("Georgia", Font.PLAIN, 13));
		label_4.setBounds(31, 402, 274, 16);
		SetHero.getContentPane().add(label_4);

		JLabel label_5 = new JLabel("Create a NAME for hero:");
		label_5.setFont(new Font("Silom", Font.BOLD, 14));
		label_5.setBounds(31, 57, 203, 16);
		SetHero.getContentPane().add(label_5);

		enterHeroName = new JTextField("hero " + heroNum);
		enterHeroName.setFont(new Font("Copperplate", Font.PLAIN, 20));
		enterHeroName.setColumns(10);
		enterHeroName.setBounds(257, 52, 130, 26);
		SetHero.getContentPane().add(enterHeroName);

	}
}
