package GUI;

import BackGroundClasses.TeamGUI;
import PSR.PaperScissorsRock;
import StartingGame.Initialization;
import StartingGame.SetHero;
public class GUIGameEnvironment {

	private int NumCities;
	private int heroNumber = 1;
	Initialization Initialization;

	public void setNumCities(int number) {
		NumCities = number;
	}

	public int getNumCities() {
		return NumCities;
	}

	public void launchPSR() {
		PSRWindow PSRWindow = new PSRWindow(this);
	}

	public void launchGTN() {
		GuessNumberWindow GuessNumberWindow = new GuessNumberWindow(this);
	}

	public void launchShop(TeamGUI team) {
		ShopWindow ShopWindow = new ShopWindow(this, team);
	}

	public void closeShop(ShopWindow window, String destination, TeamGUI Team) {
		window.closeWindow();
		if (destination == "PowerUps") {
			launchPowerUp(this, Team);
		} else if (destination == "Healings") {
			launchHealing(this, Team);

		} else if (destination == "Maps") {
			launchMap(this, Team);

		}

	}

	public void closePSR(PSRWindow window) {
		window.closeWindow();
	}

	public void closeGuessNumber(GuessNumberWindow window) {
		window.closeWindow();
	}

	public void launchDICE() {
		DiceGameWindow DiceGameWindow = new DiceGameWindow(this);
	}

	public void closeDICE(DiceGameWindow window) {
		window.closeWindow();
	}

	public void launchPowerUp(GUIGameEnvironment gameManager, TeamGUI team) {
		PowerUpWindow PowerUpWindow = new PowerUpWindow(this, team);
	}

	public void closePowerUp(String product, PowerUpWindow window, TeamGUI team) {
		window.closeWindow();
		if (product.equals("Dice")) {
			launchPurchaseDice(team);
		} else if (product.equals("Guess")) {
			launchPurchaseGuess(team);
		}

		else if (product.equals("SeeTheFuture")) {
			launchPurchaseSeeFuture(team);
		}

	}

	public void launchHealing(GUIGameEnvironment gameManager, TeamGUI team) {
		PurchaseHealingWindow PurchaseHealingWindow = new PurchaseHealingWindow(this, team);
	}

	public void closeHealing(PurchaseHealingWindow window, TeamGUI team) {
		window.closeWindow();
		launchShop(team);

	}

	public void launchMap(GUIGameEnvironment gameManager, TeamGUI team) {
		PurchaseMapWindow PurchaseMapWindow = new PurchaseMapWindow(this, team);
	}

	public void closeMap(PurchaseMapWindow window, TeamGUI team) {
		window.closeWindow();
		launchShop(team);

	}

	//
	public void launchPurchaseDice(TeamGUI Team) {

		PurchaseDiceWindow PurchaseDiceWindow = new PurchaseDiceWindow(this, Team);
	}

	public void closePurchaseDice(PurchaseDiceWindow window) {
		window.closeWindow();
	}

	public void launchPurchaseGuess(TeamGUI Team) {
		PurchaseGuessWindow PurchaseGuessWindow = new PurchaseGuessWindow(this, Team);
	}

	public void closePurchaseGuess(PurchaseGuessWindow window) {
		window.closeWindow();
	}

	public void launchPurchaseSeeFuture(TeamGUI Team) {
		PurchaseSeeTheFutureWindow PurchaseSeeTheFutureWindow = new PurchaseSeeTheFutureWindow(this, Team);
	}

	public void closePurchaseSeeFuture(PurchaseSeeTheFutureWindow window) {
		window.closeWindow();
	}


	public void launchSetUpScreen(TeamGUI Team) {
		Initialization letsGo = new Initialization(this, Team);
	}

	public void closeSetUpScreen(Initialization setUpScreen, TeamGUI Team) {
		setUpScreen.closeWindow();
		launchSetHero(Team, heroNumber);
	}

	public void launchSetHero(TeamGUI Team, int heroNumber) {
		SetHero hero = new SetHero(this, Team, heroNumber);
	}

	public void closeSetHero(SetHero setHeroScreen, TeamGUI Team) {
		setHeroScreen.closeWindow();
		heroNumber += 1;
		if (heroNumber <= Team.getNumHeros()) {
			launchSetHero(Team, heroNumber);
		} else {
			
			// for test program purpose
			launchPowerUpDenWindow(Team);
			
//			launchHosital(Team);
//			launchHeroHomeBase(Team);
		}
	}
	
	public void launchHosital(TeamGUI Team) {
		hospitalWindow hospital = new hospitalWindow(this, Team);
	}
	
	public void closeHospitalWindow(hospitalWindow window, TeamGUI Team) {
		window.closeWindow();
//		launchHeroHomeBaseMenu(Team, true);
	}
	
	
	public void launchPowerUpDenWindow(TeamGUI Team) {
		PowerUpDenWindow PowerUpDenWindow = new PowerUpDenWindow(this, Team);
	}
	
	public void closePowerUpDenWindow(PowerUpDenWindow window, TeamGUI Team) {
		window.closeWindow();
//		launchHeroHomeBaseMenu(Team, true);
	}
	
	
	
	
	
	
//	public void launchHosital(TeamGUI Team) {
//		hospitalWindow hospital = new hospitalWindow(this, Team);
//	}
	


	public void launchHeroHomeBase(TeamGUI Team) {
		// go to hero home base
	}
	
	
	
	
	
	
	
	

	// public void launchPSR() {
	// PSRWindow PSRWindow = new PSRWindow(this);
	// }

	// public void launchSetUpScreen(TeamGUI Team) {
	// Initialization letsGo = new Initialization(this, Team);
	// }
	//
	// public void closeSetUpScreen(Initialization setUpScreen, TeamGUI Team) {
	// setUpScreen.closeWindow();
	// launchCreateHeros(Team);
	// }
	//
	// public void launchCreateHeros(TeamGUI Team) {
	// for(int i = 1; i < Team.getNumHeros()+1; i++) {
	// EnterHeroName heroName = new EnterHeroName(this, Team, i);
	// }
	// }

	public static void main(String[] args) {
		 GUIGameEnvironment Game = new GUIGameEnvironment();
		 TeamGUI OurTeam = new TeamGUI();

		/////// test games
		// Game.launchPSR();
		// Game.launchGTN();
		// Game.launchDICE();
		// Game.launchShop(OurTeam);

		// TeamGUI OurTeam = new TeamGUI();
		Game.launchSetUpScreen(OurTeam);
//		Game.launchHosital(OurTeam);
//		Game.launchPowerUpDenWindow(OurTeam);
		/////// test team GUI







		//
		//
		//
		//
		// TeamGUI OurTeam = new TeamGUI();
		// Game.launchSetUpScreen(OurTeam);
		// System.out.println(OurTeam.getTeamName());
	}

}
