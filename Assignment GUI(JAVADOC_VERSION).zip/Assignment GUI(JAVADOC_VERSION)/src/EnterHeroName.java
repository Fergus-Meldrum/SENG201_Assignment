
import java.awt.EventQueue;

import javax.swing.JFrame;
import java.lang.Runnable;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;

import BackGroundClasses.TeamGUI;
import PlayingTheGame.GUIGameEnvironment;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * Class EnterHeroName
 * 
 * @author Fergus Meldrum, Chang Tu
 *
 */
public class EnterHeroName {

	private JFrame CreateHeros;
	private JTextField textField;
	private JButton btnOk;

	private GUIGameEnvironment gameManager;
	private TeamGUI Team;
	private int heroNumber;

	/**
	 * Constructor of EnterHeroName
	 * 
	 * @param manager
	 *            GUIGameEnvironment
	 * @param team
	 *            TeamGUI
	 * @param number
	 *            int
	 */
	public EnterHeroName(GUIGameEnvironment manager, TeamGUI team, int number) {
		gameManager = manager;
		Team = team;
		heroNumber = number;
		initialize();
		CreateHeros.setVisible(true);
	}

	/**
	 * Initialization of the EnterHeroName window
	 */
	private void initialize() {
		CreateHeros = new JFrame();
		CreateHeros.setBounds(100, 100, 450, 220);
		CreateHeros.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		CreateHeros.getContentPane().setLayout(null);

		JLabel lblChooseAName = new JLabel("Create a NAME for hero " + heroNumber + " : ");
		lblChooseAName.setFont(new Font("Silom", Font.BOLD, 14));
		lblChooseAName.setBounds(51, 69, 203, 16);
		CreateHeros.getContentPane().add(lblChooseAName);

		JLabel lblChooseHeroName = new JLabel("Choose Hero Name");
		lblChooseHeroName.setFont(new Font("Baskerville", Font.BOLD, 28));
		lblChooseHeroName.setBounds(31, 12, 321, 39);
		CreateHeros.getContentPane().add(lblChooseHeroName);

		textField = new JTextField();
		textField.setBounds(263, 64, 130, 26);
		CreateHeros.getContentPane().add(textField);
		textField.setColumns(10);

		btnOk = new JButton("Next");
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

			}
		});
		btnOk.setFont(new Font("Gurmukhi MN", Font.BOLD, 17));
		btnOk.setBounds(102, 118, 250, 50);
		CreateHeros.getContentPane().add(btnOk);
	}

}
