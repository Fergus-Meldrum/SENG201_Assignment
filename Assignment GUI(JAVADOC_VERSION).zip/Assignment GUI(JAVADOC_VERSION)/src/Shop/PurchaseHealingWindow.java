package Shop;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import BackGroundClasses.Product;
import BackGroundClasses.TeamGUI;
import PlayingTheGame.GUIGameEnvironment;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

/**
 * Class PurchaseHealing Window
 * 
 * @author Fergus Meldrum, Chang Tu
 *
 */
public class PurchaseHealingWindow {
	private JFrame frame;
	String result;
	GUIGameEnvironment gameManager;
	TeamGUI Team;
	private Product Healing;

	/**
	 * Constructor of PurchaseHealingWindow
	 * 
	 * @param manager
	 *            GUIGameEnvironment
	 * @param team
	 *            TeamGUI
	 */
	public PurchaseHealingWindow(GUIGameEnvironment manager, TeamGUI team) {
		gameManager = manager;
		Team = team;
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Finished Window Method
	 * 
	 * @param team
	 *            TeamGUI
	 */
	public void finishedWindow(TeamGUI team) {
		
		gameManager.closeHealing(this, team);

	}

	/**
	 * Close Window Method
	 */
	public void closeWindow() {
		frame.dispose();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 450);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		ImageIcon assistentIcon = new ImageIcon(getClass().getResource("/images/015-roboto-logo.png"));

		JLabel label_7 = new JLabel("Description\n");
		label_7.setFont(new Font("Silom", Font.PLAIN, 11));
		label_7.setBounds(95, 330, 104, 29);
		frame.getContentPane().add(label_7);

		JLabel lblBurstYourHero_2 = new JLabel("3x Healing Item");
		lblBurstYourHero_2.setFont(new Font("Georgia", Font.PLAIN, 13));
		lblBurstYourHero_2.setBounds(176, 335, 181, 16);
		frame.getContentPane().add(lblBurstYourHero_2);

		JLabel label_9 = new JLabel("Price");
		label_9.setFont(new Font("Silom", Font.PLAIN, 11));
		label_9.setBounds(95, 354, 104, 29);
		frame.getContentPane().add(label_9);

		JLabel label_10 = new JLabel("Name");
		label_10.setFont(new Font("Silom", Font.PLAIN, 11));
		label_10.setBounds(95, 309, 104, 29);
		frame.getContentPane().add(label_10);

		JLabel lblThreePacksHealing = new JLabel("Three Packs Healing Item");
		lblThreePacksHealing.setFont(new Font("Georgia", Font.PLAIN, 13));
		lblThreePacksHealing.setBounds(176, 309, 181, 16);
		frame.getContentPane().add(lblThreePacksHealing);

		JLabel label_12 = new JLabel("$65");
		label_12.setFont(new Font("Georgia", Font.PLAIN, 13));
		label_12.setBounds(176, 357, 181, 16);
		frame.getContentPane().add(label_12);

		JButton button_2 = new JButton("<< BACK\n");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				finishedWindow(Team);
			}
		});
		button_2.setFont(new Font("Gurmukhi MN", Font.BOLD, 17));
		button_2.setBounds(323, 385, 97, 34);
		frame.getContentPane().add(button_2);

		JLabel label_2 = new JLabel("");
		label_2.setText(String.valueOf(Team.getCoin()));
		label_2.setFont(new Font("Copperplate", Font.BOLD, 14));
		label_2.setBounds(383, 21, 168, 16);
		frame.getContentPane().add(label_2);

		JLabel label_5 = new JLabel("Coin");
		label_5.setFont(new Font("Copperplate", Font.BOLD, 14));
		label_5.setBounds(337, 21, 34, 16);
		frame.getContentPane().add(label_5);

		JLabel lblHIcon = new JLabel("");
		lblHIcon.setIcon(new ImageIcon(PurchaseHealingWindow.class.getResource("/images/Icon-50-18.png")));
		lblHIcon.setBounds(30, 129, 67, 60);
		frame.getContentPane().add(lblHIcon);

		JLabel lblScissorsIcon = new JLabel("");
		lblScissorsIcon.setIcon(new ImageIcon(PurchaseHealingWindow.class.getResource("/images/Icon-50-19.png")));
		lblScissorsIcon.setBounds(30, 215, 67, 60);
		frame.getContentPane().add(lblScissorsIcon);

		JLabel lblHIcon_1 = new JLabel("");
		lblHIcon_1.setIcon(new ImageIcon(PurchaseHealingWindow.class.getResource("/images/Icon-50-20.png")));
		lblHIcon_1.setBounds(30, 309, 67, 60);
		frame.getContentPane().add(lblHIcon_1);

		JButton btnOnePackHealing = new JButton("select");
		btnOnePackHealing.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Healing = new Product("Healing", 25);
				Team.addInventory(Healing);
				Team.showInventory();
				Team.setCoin(25);
				label_2.setText(String.valueOf(Team.getCoin()));
				JOptionPane.showMessageDialog(frame, "Payment sucessfull", null, 0, assistentIcon);

			}
		});

		btnOnePackHealing.setFont(new Font("Copperplate", Font.BOLD, 12));
		btnOnePackHealing.setBounds(362, 145, 58, 34);
		frame.getContentPane().add(btnOnePackHealing);

		JLabel lblWeOfferThe = new JLabel("We offer the following Healing Products:\n");
		lblWeOfferThe.setFont(new Font("Silom", Font.BOLD, 14));
		lblWeOfferThe.setBounds(30, 87, 398, 16);
		frame.getContentPane().add(lblWeOfferThe);

		JLabel lblHealing = new JLabel("Description\n");
		lblHealing.setFont(new Font("Silom", Font.PLAIN, 11));
		lblHealing.setBounds(95, 136, 104, 29);
		frame.getContentPane().add(lblHealing);

		JLabel lblBurstYourHero = new JLabel("1x Healing Item");
		lblBurstYourHero.setFont(new Font("Georgia", Font.PLAIN, 13));
		lblBurstYourHero.setBounds(176, 141, 181, 16);
		frame.getContentPane().add(lblBurstYourHero);

		JLabel lblPrice = new JLabel("Price");
		lblPrice.setFont(new Font("Silom", Font.PLAIN, 11));
		lblPrice.setBounds(95, 160, 104, 29);
		frame.getContentPane().add(lblPrice);

		JLabel lblProductName = new JLabel("Name");
		lblProductName.setFont(new Font("Silom", Font.PLAIN, 11));
		lblProductName.setBounds(95, 115, 104, 29);
		frame.getContentPane().add(lblProductName);

		JLabel lblOnePackHealing = new JLabel("One Pack Healing Item");
		lblOnePackHealing.setFont(new Font("Georgia", Font.PLAIN, 13));
		lblOnePackHealing.setBounds(176, 115, 181, 16);
		frame.getContentPane().add(lblOnePackHealing);

		JLabel label = new JLabel("$25");
		label.setFont(new Font("Georgia", Font.PLAIN, 13));
		label.setBounds(176, 163, 181, 16);
		frame.getContentPane().add(label);

		JButton button = new JButton("select");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				Healing = new Product("Healing", 40);
				Team.addInventory(Healing);
				Team.addInventory(Healing);
				Team.showInventory();
				Team.setCoin(40);
				label_2.setText(String.valueOf(Team.getCoin()));
				JOptionPane.showMessageDialog(frame, "Payment sucessfull", null, 0, assistentIcon);

			}
		});
		button.setFont(new Font("Copperplate", Font.BOLD, 12));
		button.setBounds(362, 231, 58, 34);
		frame.getContentPane().add(button);

		JLabel label_1 = new JLabel("Description\n");
		label_1.setFont(new Font("Silom", Font.PLAIN, 11));
		label_1.setBounds(95, 222, 104, 29);
		frame.getContentPane().add(label_1);

		JLabel lblBurstYourHero_1 = new JLabel("2x Healing Item");
		lblBurstYourHero_1.setFont(new Font("Georgia", Font.PLAIN, 13));
		lblBurstYourHero_1.setBounds(176, 227, 181, 16);
		frame.getContentPane().add(lblBurstYourHero_1);

		JLabel label_3 = new JLabel("Price");
		label_3.setFont(new Font("Silom", Font.PLAIN, 11));
		label_3.setBounds(95, 246, 104, 29);
		frame.getContentPane().add(label_3);

		JLabel label_4 = new JLabel("Name");
		label_4.setFont(new Font("Silom", Font.PLAIN, 11));
		label_4.setBounds(95, 201, 104, 29);
		frame.getContentPane().add(label_4);

		JLabel lblTwoPacksHealing = new JLabel("Two Packs Healing Item");
		lblTwoPacksHealing.setFont(new Font("Georgia", Font.PLAIN, 13));
		lblTwoPacksHealing.setBounds(176, 201, 181, 16);
		frame.getContentPane().add(lblTwoPacksHealing);

		JLabel label_6 = new JLabel("$40");
		label_6.setFont(new Font("Georgia", Font.PLAIN, 13));
		label_6.setBounds(176, 249, 181, 16);
		frame.getContentPane().add(label_6);

		JButton button_1 = new JButton("select");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Healing = new Product("Healing", 65);
				Team.addInventory(Healing);
				Team.addInventory(Healing);
				Team.addInventory(Healing);
				Team.showInventory();
				Team.setCoin(65);
				label_2.setText(String.valueOf(Team.getCoin()));
				JOptionPane.showMessageDialog(frame, "Payment sucessfull", null, 0, assistentIcon);

			}
		});
		button_1.setFont(new Font("Copperplate", Font.BOLD, 12));
		button_1.setBounds(362, 339, 58, 34);
		frame.getContentPane().add(button_1);

		JLabel label_8 = new JLabel("");
		label_8.setIcon(new ImageIcon(PurchaseHealingWindow.class.getResource("/images/Icon-20.png")));
		label_8.setFont(new Font("Silom", Font.BOLD, 14));
		label_8.setBounds(307, 21, 34, 16);
		frame.getContentPane().add(label_8);

		JLabel lblPurchaseHealings = new JLabel("Healings");
		lblPurchaseHealings.setFont(new Font("Baskerville", Font.BOLD, 28));
		lblPurchaseHealings.setBounds(81, 21, 347, 39);
		frame.getContentPane().add(lblPurchaseHealings);

		JLabel label_11 = new JLabel("");
		label_11.setIcon(new ImageIcon(PurchaseHealingWindow.class.getResource("/images/Icon-50-27.png")));
		label_11.setFont(new Font("Silom", Font.BOLD, 14));
		label_11.setBounds(16, 10, 104, 50);
		frame.getContentPane().add(label_11);

		JLabel lblAHealingItem = new JLabel("A Healing Item can be applied to a Hero at Hospital to boost");
		lblAHealingItem.setBounds(30, 59, 389, 16);
		frame.getContentPane().add(lblAHealingItem);

		JLabel lblNewLabel = new JLabel("their health 25%");
		lblNewLabel.setBounds(160, 72, 110, 16);
		frame.getContentPane().add(lblNewLabel);

	}
}
