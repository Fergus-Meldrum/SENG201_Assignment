package Shop;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.lang.Runnable;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import BackGroundClasses.TeamGUI;
import PlayingTheGame.GUIGameEnvironment;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import BackGroundClasses.Product;
import javax.swing.ImageIcon;;

/**
 * Class PurchaseDiceWindow
 * 
 * @author Fergus Meldrum, Chang Tu
 */
public class PurchaseDiceWindow {

	private JFrame frame;
	GUIGameEnvironment gameManager;
	TeamGUI Team;
	private Product Dice;
	ImageIcon assistentIcon = new ImageIcon(getClass().getResource("/images/015-roboto-logo.png"));

	/**
	 * Constructor of PurchaseDiceWindow
	 * 
	 * @param manager
	 *            GUIGameEnvironment
	 * @param team
	 *            TeamGUI
	 */
	public PurchaseDiceWindow(GUIGameEnvironment manager, TeamGUI team) {
		gameManager = manager;
		Team = team;
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Close Window Method
	 */
	public void closeWindow() {
		frame.dispose();
	}

	/**
	 * Finished Window Method
	 * 
	 */
	public void finishedWindow() {
		gameManager.closePurchaseDice(this);
	}

	/**
	 * Initialize the contents of the PurchaseDiceWindow.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel lblPurchaseDice = new JLabel("Dice");
		lblPurchaseDice.setFont(new Font("Baskerville", Font.BOLD, 28));
		lblPurchaseDice.setBounds(104, 33, 212, 39);
		frame.getContentPane().add(lblPurchaseDice);

		JLabel lblEachDiceCost = new JLabel("Each DICE will cost you 20 coins\n");
		lblEachDiceCost.setFont(new Font("Silom", Font.BOLD, 14));
		lblEachDiceCost.setBounds(19, 101, 398, 16);
		frame.getContentPane().add(lblEachDiceCost);

		JLabel lblDice = new JLabel("Coin");
		lblDice.setFont(new Font("Copperplate", Font.BOLD, 14));
		lblDice.setBounds(301, 21, 34, 16);
		frame.getContentPane().add(lblDice);

		JLabel label = new JLabel("");
		label.setText(String.valueOf(Team.getCoin()));
		label.setFont(new Font("Copperplate", Font.BOLD, 14));
		label.setBounds(347, 21, 168, 16);
		frame.getContentPane().add(label);

		JButton btnBuyIt = new JButton("Buy 1x Dice\n");
		frame.getRootPane().setDefaultButton( btnBuyIt );

		btnBuyIt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// put a message box here show sucessfull payment
				Dice = new Product("1x Dice", 20);
				Team.addInventory(Dice);
				Team.showInventory();
				Team.setCoin(20);
				label.setText(String.valueOf(Team.getCoin()));
				JOptionPane.showMessageDialog(frame, "Payment sucessfull", null, 0, assistentIcon);
			}
		});
		btnBuyIt.setFont(new Font("Gurmukhi MN", Font.BOLD, 17));
		btnBuyIt.setBounds(95, 129, 240, 50);
		frame.getContentPane().add(btnBuyIt);

		JButton btnBack = new JButton("<< BACK\n");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				finishedWindow();
				gameManager.launchPowerUp(gameManager, Team);
			}
		});
		btnBack.setFont(new Font("Gurmukhi MN", Font.BOLD, 17));
		btnBack.setBounds(95, 199, 250, 50);
		frame.getContentPane().add(btnBack);

		JLabel label_1 = new JLabel("Coin");
		label_1.setIcon(new ImageIcon(PurchaseDiceWindow.class.getResource("/images/013-dice.png")));
		label_1.setFont(new Font("Silom", Font.BOLD, 14));
		label_1.setBounds(29, 17, 70, 72);
		frame.getContentPane().add(label_1);

		JLabel label_2 = new JLabel("");
		label_2.setIcon(new ImageIcon(PurchaseDiceWindow.class.getResource("/images/Icon-20.png")));
		label_2.setFont(new Font("Silom", Font.BOLD, 14));
		label_2.setBounds(271, 21, 34, 16);
		frame.getContentPane().add(label_2);

	}
}
