package Shop;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.lang.Runnable;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import BackGroundClasses.Product;
import BackGroundClasses.TeamGUI;
import PlayingTheGame.GUIGameEnvironment;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

/**
 * 
 * @author Fergus Meldrum, Chang Tu
 *
 */
public class PurchaseGuessWindow {

	private JFrame frame;
	GUIGameEnvironment gameManager;
	TeamGUI Team;
	private Product Guess;
	ImageIcon assistentIcon = new ImageIcon(getClass().getResource("/images/015-roboto-logo.png"));

	/**
	 * Constructor of PurchaseGuessWindow
	 * 
	 * @param manager
	 *            GUIGameEnvironment
	 * @param team
	 *            TeamGUI
	 */
	public PurchaseGuessWindow(GUIGameEnvironment manager, TeamGUI team) {
		gameManager = manager;
		Team = team;
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Close Window Method
	 */
	public void closeWindow() {
		frame.dispose();
	}

	/**
	 * Finished Window Method
	 */
	public void finishedWindow() {
		gameManager.closePurchaseGuess(this);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel lblPurchaseDice = new JLabel("Purchase Guesses\n");
		lblPurchaseDice.setFont(new Font("Baskerville", Font.BOLD, 28));
		lblPurchaseDice.setBounds(75, 33, 257, 39);
		frame.getContentPane().add(lblPurchaseDice);

		JLabel lblEachDiceCost = new JLabel("Each Guess will cost you 20 coins\n");
		lblEachDiceCost.setFont(new Font("Silom", Font.BOLD, 14));
		lblEachDiceCost.setBounds(29, 101, 398, 16);
		frame.getContentPane().add(lblEachDiceCost);

		JLabel label = new JLabel("");
		label.setFont(new Font("Copperplate", Font.BOLD, 14));
		label.setText(String.valueOf(Team.getCoin()));

		label.setBounds(373, 20, 168, 16);
		frame.getContentPane().add(label);

		JLabel label_1 = new JLabel("Coin");
		label_1.setFont(new Font("Copperplate", Font.BOLD, 14));
		label_1.setBounds(327, 20, 34, 16);
		frame.getContentPane().add(label_1);

		JButton btnBuyIt = new JButton("Buy it!\n");
		frame.getRootPane().setDefaultButton( btnBuyIt );

		btnBuyIt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// put a message box here show sucessfull payment
				Guess = new Product("1x Guess", 20);
				Team.addInventory(Guess);
				Team.showInventory();
				Team.setCoin(20);
				label.setText(String.valueOf(Team.getCoin()));
				JOptionPane.showMessageDialog(frame, "Payment sucessfull", null, 0, assistentIcon);
			}
		});
		btnBuyIt.setFont(new Font("Gurmukhi MN", Font.BOLD, 17));
		btnBuyIt.setBounds(95, 129, 250, 50);
		frame.getContentPane().add(btnBuyIt);

		JButton btnBack = new JButton("<< BACK\n");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				finishedWindow();
				gameManager.launchPowerUp(gameManager, Team);
			}
		});
		btnBack.setFont(new Font("Gurmukhi MN", Font.BOLD, 17));
		btnBack.setBounds(95, 199, 250, 50);
		frame.getContentPane().add(btnBack);

		JLabel label_2 = new JLabel("");
		label_2.setIcon(new ImageIcon(PurchaseGuessWindow.class.getResource("/images/Icon-20.png")));
		label_2.setFont(new Font("Silom", Font.BOLD, 14));
		label_2.setBounds(298, 21, 34, 16);
		frame.getContentPane().add(label_2);

		JLabel label_3 = new JLabel("");
		label_3.setIcon(new ImageIcon(PurchaseGuessWindow.class.getResource("/images/005-three.png")));
		label_3.setFont(new Font("Silom", Font.BOLD, 14));
		label_3.setBounds(6, 9, 75, 80);
		frame.getContentPane().add(label_3);

	}

}
