package Shop;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.lang.Runnable;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import BackGroundClasses.Product;
import BackGroundClasses.TeamGUI;
import PlayingTheGame.GUIGameEnvironment;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

/**
 * 
 * @author Fergus Meldrum, Chang Tu
 *
 */
public class PurchaseSeeTheFutureWindow {

	private JFrame frame;
	GUIGameEnvironment gameManager;
	TeamGUI Team;
	private Product SeeTheFuture;
	ImageIcon assistentIcon = new ImageIcon(getClass().getResource("/images/015-roboto-logo.png"));

	/**
	 * Constructor of PurchaseSeeTheFutureWindow
	 * 
	 * @param manager
	 *            GUIGameEnvironment
	 * @param team
	 *            TeamGUI
	 */
	public PurchaseSeeTheFutureWindow(GUIGameEnvironment manager, TeamGUI team) {
		gameManager = manager;
		Team = team;
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Close Window Method
	 */
	public void closeWindow() {
		frame.dispose();
	}

	/**
	 * Finished Window Method
	 * 
	 */
	public void finishedWindow() {
		gameManager.closePurchaseSeeFuture(this);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel lblEachDiceCost = new JLabel("Each See future power up will cost you 10 coins,\n");
		lblEachDiceCost.setFont(new Font("Silom", Font.BOLD, 14));
		lblEachDiceCost.setBounds(27, 90, 398, 16);
		frame.getContentPane().add(lblEachDiceCost);

		JLabel label = new JLabel("");
		label.setFont(new Font("Copperplate", Font.BOLD, 14));
		label.setText(String.valueOf(Team.getCoin()));
		label.setBounds(394, 21, 168, 16);
		frame.getContentPane().add(label);

		JLabel label_1 = new JLabel("Coin");
		label_1.setFont(new Font("Copperplate", Font.BOLD, 14));
		label_1.setBounds(348, 21, 34, 16);
		frame.getContentPane().add(label_1);

		JButton btnBuyIt = new JButton("Buy it!\n");
		frame.getRootPane().setDefaultButton( btnBuyIt );

		btnBuyIt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SeeTheFuture = new Product("1x SeeTheFuture", 20);
				Team.addInventory(SeeTheFuture);
				Team.showInventory();
				Team.setCoin(20);
				label.setText(String.valueOf(Team.getCoin()));
				JOptionPane.showMessageDialog(frame, "Payment sucessfull", null, 0, assistentIcon);

			}
		});
		btnBuyIt.setFont(new Font("Gurmukhi MN", Font.BOLD, 17));
		btnBuyIt.setBounds(95, 129, 250, 50);
		frame.getContentPane().add(btnBuyIt);

		JButton btnBack = new JButton("<< BACK\n");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				finishedWindow();
				gameManager.launchPowerUp(gameManager, Team);
			}
		});
		btnBack.setFont(new Font("Gurmukhi MN", Font.BOLD, 17));
		btnBack.setBounds(95, 199, 250, 50);
		frame.getContentPane().add(btnBack);

		JLabel lblPurchaseDice = new JLabel("See The Future\n");
		lblPurchaseDice.setFont(new Font("Baskerville", Font.BOLD, 28));
		lblPurchaseDice.setBounds(95, 35, 398, 39);
		frame.getContentPane().add(lblPurchaseDice);

		JLabel label_2 = new JLabel("");
		label_2.setIcon(new ImageIcon(PurchaseSeeTheFutureWindow.class.getResource("/images/012-clock.png")));
		label_2.setBounds(6, 6, 77, 77);
		frame.getContentPane().add(label_2);

	}

}
