package Shop;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.lang.Runnable;
import javax.swing.JLabel;

import BackGroundClasses.TeamGUI;
import PlayingTheGame.GUIGameEnvironment;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

/**
 * Class ShopWindow
 * 
 * @author Fergus Meldrum, Chang Tu
 *
 */
public class ShopWindow {

	private JFrame frame;
	private GUIGameEnvironment gameManager;
	private TeamGUI Team;
	private ImageIcon assistentIcon = new ImageIcon(getClass().getResource("/images/015-roboto-logo.png"));

	/**
	 * Constructor of ShopWindow
	 * 
	 * @param manager
	 *            GUIGameEnvironment
	 * @param team
	 *            TeamGUI
	 */
	public ShopWindow(GUIGameEnvironment manager, TeamGUI team) {
		gameManager = manager;
		Team = team;
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Close Window Method
	 */
	public void closeWindow() {
		frame.dispose();
	}

	/**
	 * Finished Window Method
	 * 
	 * @param destination
	 *            String
	 */
	public void finishedWindow(String destination) {
		gameManager.closeShop(this, destination, Team);
	}

	/**
	 * Initialize the contents of the ShopWindow.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 500, 350);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel lblWelcomeToThe = new JLabel("Welcome to the Shop!");
		lblWelcomeToThe.setFont(new Font("Baskerville", Font.BOLD, 28));
		lblWelcomeToThe.setBounds(37, 19, 321, 39);
		frame.getContentPane().add(lblWelcomeToThe);

		JLabel lblCoin = new JLabel("Coin");
		lblCoin.setFont(new Font("Copperplate", Font.BOLD, 14));
		lblCoin.setBounds(370, 19, 56, 16);
		frame.getContentPane().add(lblCoin);

		JLabel lblWeSaleFollowing = new JLabel("We sale following items:");
		lblWeSaleFollowing.setFont(new Font("Silom", Font.BOLD, 14));
		lblWeSaleFollowing.setBounds(124, 86, 203, 16);
		frame.getContentPane().add(lblWeSaleFollowing);

		JButton btnPowerUps = new JButton("Power Ups");
		btnPowerUps.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				finishedWindow("PowerUps");
			}
		});
		btnPowerUps.setFont(new Font("Copperplate", Font.PLAIN, 16));
		btnPowerUps.setBounds(47, 222, 104, 50);
		frame.getContentPane().add(btnPowerUps);

		JButton btnHealingitems = new JButton("Healings");
		btnHealingitems.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				finishedWindow("Healings");
			}
		});
		btnHealingitems.setFont(new Font("Copperplate", Font.PLAIN, 16));
		btnHealingitems.setBounds(163, 222, 104, 50);
		frame.getContentPane().add(btnHealingitems);

		JButton btnMaps = new JButton("Maps");
		btnMaps.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				finishedWindow("Maps");
			}
		});
		btnMaps.setFont(new Font("Copperplate", Font.PLAIN, 16));
		btnMaps.setBounds(279, 222, 104, 50);
		frame.getContentPane().add(btnMaps);

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(ShopWindow.class.getResource("/images/015-roboto-logo.png")));
		lblNewLabel.setBounds(47, 53, 77, 77);
		frame.getContentPane().add(lblNewLabel);

		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(ShopWindow.class.getResource("/images/003-squares.png")));
		label.setBounds(77, 144, 64, 77);
		frame.getContentPane().add(label);

		JLabel label_1 = new JLabel("");
		label_1.setIcon(new ImageIcon(ShopWindow.class.getResource("/images/Icon-50-20.png")));
		label_1.setBounds(189, 144, 64, 77);
		frame.getContentPane().add(label_1);

		JLabel label_2 = new JLabel("");
		label_2.setIcon(new ImageIcon(ShopWindow.class.getResource("/images/010-location.png")));
		label_2.setBounds(293, 144, 77, 77);
		frame.getContentPane().add(label_2);

		JButton button = new JButton("< BACK");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				finishedWindow("HeroHomeBase");
			}
		});
		button.setFont(new Font("Gurmukhi MN", Font.BOLD, 17));
		button.setBounds(398, 260, 82, 50);
		frame.getContentPane().add(button);

		JLabel lblIcon = new JLabel("");
		lblIcon.setIcon(new ImageIcon(ShopWindow.class.getResource("/images/Icon-20.png")));
		lblIcon.setFont(new Font("Georgia", Font.BOLD, 14));
		lblIcon.setBounds(335, 19, 34, 16);
		frame.getContentPane().add(lblIcon);

		JLabel label_3 = new JLabel("");
		label_3.setText(String.valueOf(Team.getCoin()));
		label_3.setFont(new Font("Copperplate", Font.BOLD, 14));
		label_3.setBounds(419, 19, 168, 16);
		frame.getContentPane().add(label_3);
	}

}
