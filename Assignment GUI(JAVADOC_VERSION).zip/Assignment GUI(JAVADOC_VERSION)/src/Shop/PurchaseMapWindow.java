package Shop;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.lang.Runnable;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import BackGroundClasses.Product;
import BackGroundClasses.TeamGUI;
import PlayingTheGame.GUIGameEnvironment;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

/**
 * 
 * @author Fergus Meldrum, Chang Tu
 *
 */
public class PurchaseMapWindow {

	private JFrame frame;
	GUIGameEnvironment gameManager;
	TeamGUI Team;
	private Product Map;
	ImageIcon assistentIcon = new ImageIcon(getClass().getResource("/images/015-roboto-logo.png"));

	/**
	 * Constructor of PurchaseMapWindow
	 * 
	 * @param manager
	 *            GUIGameEnvironment
	 * @param team
	 *            TeamGUI
	 */
	public PurchaseMapWindow(GUIGameEnvironment manager, TeamGUI team) {
		gameManager = manager;
		Team = team;
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Close Window Method
	 */
	public void closeWindow() {
		frame.dispose();
	}

	/**
	 * Finished Window Method
	 * 
	 * @param team
	 *            TeamGUI
	 */
	public void finishedWindow(TeamGUI Team) {
		gameManager.closeMap(this, Team);
	}

	// /**
	// * Launch the application.
	// */
	// public static void main(String[] args) {
	// EventQueue.invokeLater(new Runnable() {
	// public void run() {
	// try {
	// PurchaseMapWindow window = new PurchaseMapWindow();
	// window.frame.setVisible(true);
	// } catch (Exception e) {
	// e.printStackTrace();
	// }
	// }
	// });
	// }
	//
	// /**
	// * Create the application.
	// */
	// public PurchaseMapWindow() {
	// initialize();
	// }

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel lblPurchaseMap = new JLabel("Map");
		lblPurchaseMap.setFont(new Font("Baskerville", Font.BOLD, 28));
		lblPurchaseMap.setBounds(95, 37, 212, 39);
		frame.getContentPane().add(lblPurchaseMap);

		JLabel lblEachMapCost = new JLabel("Each Map will cost you 10 coins\n");
		lblEachMapCost.setFont(new Font("Silom", Font.BOLD, 14));
		lblEachMapCost.setBounds(27, 101, 398, 16);
		frame.getContentPane().add(lblEachMapCost);

		JLabel label = new JLabel("");
		label.setText(String.valueOf(Team.getCoin()));
		label.setFont(new Font("Copperplate", Font.BOLD, 14));
		label.setBounds(351, 20, 168, 16);
		frame.getContentPane().add(label);

		JLabel label_1 = new JLabel("Coin");
		label_1.setFont(new Font("Copperplate", Font.BOLD, 14));
		label_1.setBounds(305, 20, 34, 16);
		frame.getContentPane().add(label_1);

		JButton btnBuyIt = new JButton("Buy it!\n");
		frame.getRootPane().setDefaultButton( btnBuyIt );

		btnBuyIt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Map = new Product("1x Map", 20);
				Team.addInventory(Map);
				Team.showInventory();
				Team.setCoin(20);
				label.setText(String.valueOf(Team.getCoin()));
				JOptionPane.showMessageDialog(frame, "Payment sucessfull", null, 0, assistentIcon);
			}
		});
		btnBuyIt.setFont(new Font("Gurmukhi MN", Font.BOLD, 17));
		btnBuyIt.setBounds(95, 129, 250, 50);
		frame.getContentPane().add(btnBuyIt);

		JButton btnBack = new JButton("<< BACK\n");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				finishedWindow(Team);
			}
		});
		btnBack.setFont(new Font("Gurmukhi MN", Font.BOLD, 17));
		btnBack.setBounds(95, 199, 250, 50);
		frame.getContentPane().add(btnBack);

		JLabel label_2 = new JLabel("");
		label_2.setIcon(new ImageIcon(PurchaseMapWindow.class.getResource("/images/Icon-20.png")));
		label_2.setFont(new Font("Copperplate", Font.BOLD, 14));
		label_2.setBounds(273, 19, 34, 16);
		frame.getContentPane().add(label_2);

		JLabel label_3 = new JLabel("");
		label_3.setIcon(new ImageIcon(PurchaseMapWindow.class.getResource("/images/010-location.png")));
		label_3.setFont(new Font("Copperplate", Font.BOLD, 14));
		label_3.setBounds(18, 20, 92, 64);
		frame.getContentPane().add(label_3);

	}
}
