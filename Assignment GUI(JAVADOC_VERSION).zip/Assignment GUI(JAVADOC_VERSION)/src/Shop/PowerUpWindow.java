package Shop;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.lang.Runnable;
import javax.swing.JLabel;

import BackGroundClasses.TeamGUI;
import PlayingTheGame.GUIGameEnvironment;

import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

/**
 * Class PowerUpWindow
 * 
 * @author Fergus Meldrum, Chang Tu
 *
 */
public class PowerUpWindow {

	private JFrame frame;
	GUIGameEnvironment gameManager;
	TeamGUI Team;

	/**
	 * Constructor of PowerUpWindow
	 * 
	 * @param manager
	 *            GUIGameEnvironment
	 * @param team
	 *            TeamGUI
	 */
	public PowerUpWindow(GUIGameEnvironment manager, TeamGUI team) {
		gameManager = manager;
		Team = team;
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Close Window Method
	 */
	public void closeWindow() {
		frame.dispose();
	}

	/**
	 * Finished Window Method
	 * 
	 * @param product
	 *            String
	 * @param team
	 *            TeamGUI
	 */
	public void finishedWindow(String product, TeamGUI team) {
		gameManager.closePowerUp(product, this, team);

	}

	/**
	 * Initialize the contents of the PowerUpWindow.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 500, 350);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel lblWeOfferFollowing = new JLabel("Power Ups");
		lblWeOfferFollowing.setFont(new Font("Baskerville", Font.BOLD, 28));
		lblWeOfferFollowing.setBounds(107, 19, 174, 39);
		frame.getContentPane().add(lblWeOfferFollowing);

		JLabel lblWeSaleFollowing = new JLabel("We sale following Power Ups, select to purchase:");
		lblWeSaleFollowing.setFont(new Font("Silom", Font.BOLD, 14));
		lblWeSaleFollowing.setBounds(41, 73, 453, 16);
		frame.getContentPane().add(lblWeSaleFollowing);

		JButton btnxDice = new JButton("Dice");
		btnxDice.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				finishedWindow("Dice", Team);

			}
		});
		btnxDice.setFont(new Font("Gill Sans", Font.PLAIN, 16));
		btnxDice.setBounds(41, 215, 104, 50);
		frame.getContentPane().add(btnxDice);

		JButton btnxGuess = new JButton("Guess");
		btnxGuess.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				finishedWindow("Guess", Team);
			}
		});
		btnxGuess.setFont(new Font("Gill Sans", Font.PLAIN, 16));
		btnxGuess.setBounds(157, 215, 104, 50);
		frame.getContentPane().add(btnxGuess);

		JButton btnSeeTheFuture = new JButton("See the future");
		btnSeeTheFuture.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				finishedWindow("SeeTheFuture", Team);

			}
		});
		btnSeeTheFuture.setFont(new Font("Gill Sans", Font.PLAIN, 16));
		btnSeeTheFuture.setBounds(273, 215, 104, 50);
		frame.getContentPane().add(btnSeeTheFuture);

		JButton button_4 = new JButton("< BACK");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				finishedWindow("ShopMainMenu", Team);
			}
		});
		button_4.setFont(new Font("Gurmukhi MN", Font.BOLD, 17));
		button_4.setBounds(392, 253, 82, 50);
		frame.getContentPane().add(button_4);

		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(PowerUpWindow.class.getResource("/images/013-dice.png")));
		label.setBounds(41, 128, 104, 77);
		frame.getContentPane().add(label);

		JLabel label_1 = new JLabel("");
		label_1.setIcon(new ImageIcon(PowerUpWindow.class.getResource("/images/009-interface.png")));
		label_1.setBounds(168, 128, 104, 77);
		frame.getContentPane().add(label_1);

		JLabel label_2 = new JLabel("");
		label_2.setIcon(new ImageIcon(PowerUpWindow.class.getResource("/images/012-clock.png")));
		label_2.setBounds(296, 128, 104, 77);
		frame.getContentPane().add(label_2);

		JLabel label_3 = new JLabel("");
		label_3.setIcon(new ImageIcon(PowerUpWindow.class.getResource("/images/003-squares.png")));
		label_3.setBounds(35, -13, 121, 77);
		frame.getContentPane().add(label_3);

		JLabel label_4 = new JLabel("");
		label_4.setText(String.valueOf(Team.getCoin()));
		label_4.setFont(new Font("Copperplate", Font.BOLD, 14));
		label_4.setBounds(410, 19, 168, 16);
		frame.getContentPane().add(label_4);

		JLabel label_5 = new JLabel("Coin");
		label_5.setFont(new Font("Copperplate", Font.BOLD, 14));
		label_5.setBounds(364, 19, 34, 16);
		frame.getContentPane().add(label_5);

		JLabel label_6 = new JLabel("");
		label_6.setIcon(new ImageIcon(PowerUpWindow.class.getResource("/images/Icon-20.png")));
		label_6.setFont(new Font("Silom", Font.BOLD, 14));
		label_6.setBounds(335, 20, 34, 16);
		frame.getContentPane().add(label_6);
	}

}
