import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JRadioButton;
import javax.swing.JToggleButton;
import javax.swing.JTextArea;
import javax.swing.JEditorPane;
import javax.swing.JSpinner;
import javax.swing.JList;
import javax.swing.AbstractListModel;
import javax.swing.BorderFactory;
import javax.swing.JScrollPane;
import javax.swing.JScrollBar;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JTabbedPane;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.UIManager;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLayeredPane;

/**
 * Class StartNewGame
 * 
 * @author Fergus Meldrum, Chang Tu
 *
 */
public class StartNewGame {

	private JFrame frmLogin;

	/**
	 * Main method
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StartNewGame window = new StartNewGame();
					window.frmLogin.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * StartNewGame initialization
	 */
	public StartNewGame() {
		initialize();
	}

	/**
	 * initialization
	 */
	private void initialize() {
		frmLogin = new JFrame();
		frmLogin.setTitle("Login Window");
		frmLogin.setBounds(100, 100, 450, 300);
		frmLogin.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmLogin.getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("HERO vs. VILLAIN");
		lblNewLabel.setFont(new Font("Baskerville", Font.BOLD, 32));
		lblNewLabel.setBounds(65, 29, 321, 39);
		frmLogin.getContentPane().add(lblNewLabel);

		JButton btnNewGame = new JButton("START");
		btnNewGame.setFont(new Font("Gurmukhi MN", Font.BOLD, 17));
		btnNewGame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewGame.setBounds(95, 157, 250, 50);
		frmLogin.getContentPane().add(btnNewGame);

		JButton btnExit = new JButton("EXIT");
		btnExit.setFont(new Font("Gurmukhi MN", Font.BOLD, 17));

		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnExit.setBounds(95, 219, 250, 50);
		frmLogin.getContentPane().add(btnExit);

		JButton button = new JButton("?");
		button.setOpaque(false);
		button.setFocusPainted(false);
		button.setBorderPainted(false);
		button.setContentAreaFilled(false);
		button.setBorder(BorderFactory.createEmptyBorder(1, 1, 1, 1));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

			}
		});
		button.setBounds(374, 29, 38, 39);
		frmLogin.getContentPane().add(button);

		JLabel lblNewLabel_1 = new JLabel("Game description may goes here:::");
		lblNewLabel_1.setBackground(new Color(0, 0, 0));
		lblNewLabel_1.setBounds(56, 80, 332, 58);
		frmLogin.getContentPane().add(lblNewLabel_1);
	}
}
