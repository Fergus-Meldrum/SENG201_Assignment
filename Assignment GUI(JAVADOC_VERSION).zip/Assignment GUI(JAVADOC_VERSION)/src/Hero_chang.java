package BackGroundClasses;

import java.util.ArrayList;

public class Hero {
	
	private String HeroName;
	private String HeroType;
	// arraylist
	private String Str_Inven = "";
	public ArrayList<Product> Type_Inven = new ArrayList<Product>();	

	
	public String getHeroInventory() {
		Str_Inven += Type_Inven.get(Type_Inven.size()-1).getProductName()+"\n";
		return Str_Inven;
	}
	public void addInventory(Product product) {
		Type_Inven.add(product);
	}

	
	public void ApplyPowerUp(Product product) {
		Type_Inven.add(product);

	}
	
	
	public void setName(String name) {
		HeroName = name;
	}
	
	public String getHeroName() {
		return HeroName;
	}
	
	public void setType(String type) {
		HeroType = type;
	}
	
	public String getHeroType() {
		return HeroType;
	}

}

