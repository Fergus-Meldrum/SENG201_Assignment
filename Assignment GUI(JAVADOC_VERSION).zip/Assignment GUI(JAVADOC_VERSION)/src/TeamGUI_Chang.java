package BackGroundClasses;
import java.util.ArrayList;

import BackGroundClasses.Hero;


public class TeamGUI {
	private int coin = 1000;	
	private String teamName;
	private int NumHeros;
	private ArrayList<Hero> TeamRoster  = new ArrayList<Hero>();
	private ArrayList<String> HeroNames  = new ArrayList<String>();
	public ArrayList<Product> Inventory = new ArrayList<Product>();
	private boolean hasHealing = false;
	private String inventory_string;
	Hero hero;
	String CurrentInventory = "None";
//	Product product= new Product("Healing", 65);
	private boolean hasDice;

	
	
	
	public ArrayList<String> getHeroNameList() {
		for (Hero hero : TeamRoster) { 
			HeroNames.add(hero.getHeroName()); 
			}
		return HeroNames;
	}
	

	public void addInventory(Product product) {
		Inventory.add(product);
	}



	public void setCoin(int cost) {
		coin -= cost;
	}
	
	
	public int getCoin() {
		return coin;
	}

	
	
	public void setTeamName(String name) {
		teamName = name;
	}
	
	public String getTeamName() {
		return teamName;
	}
	
	public void setNumHeros(int number) {
		NumHeros = number;
	}
	
	public int getNumHeros() {
		return NumHeros;
	}
	
	/**
	 * adds hero to team roster
	 * @param hero to be added
	 */
	public void addHero(Hero hero) {
		TeamRoster.add(hero);
	}
	
	
	public ArrayList<String> getTeamNames() {
		for (Hero hero: TeamRoster) {
			HeroNames.add(hero.getHeroName());
		}
		return HeroNames;
	}
	

	
	public boolean getHasHealing() {	
		// test healing only
//		this.addInventory(product);
		
		
		
		for (Product item : Inventory) {
			if (item.getProductName().equals("Healing")) {
				hasHealing = true;
			}
		}
		return hasHealing;
	}
	
	
	public String showInventory() {
		inventory_string = "";
		if (Inventory.isEmpty()) {
			inventory_string =  "You Have no items in Inventory";
		}
		else {
			for (Product item : Inventory) {
				inventory_string += item.getProductName()+"\n";
		}
		}
		return inventory_string;
	}
	
	
	public void removeHealing() {
		System.out.println(this.showInventory());
		for (Product item : Inventory) {
			if (item.getProductName().equals("Healing")) {
				Inventory.remove(item);
				break;
			}				
		}
		// test only
//		System.out.println(this.showInventory());
	}
	
	public void removeDice() {
		System.out.println(this.showInventory());
		for (Product item : Inventory) {
			if (item.getProductName().equals("1x Dice")) {
				Inventory.remove(item);

				break;
			}				

		}
		// test only
//		System.out.println(this.showInventory());

	}
	
	public void removeGuess() {
		System.out.println(this.showInventory());
		for (Product item : Inventory) {
			if (item.getProductName().equals("1x Guess")) {
				Inventory.remove(item);
				break;
			}				
		}
		// test only
//		System.out.println(this.showInventory());

	}
	
	
	public void removeSeeTheFuture() {
		System.out.println(this.showInventory());
		for (Product item : Inventory) {
			if (item.getProductName().equals("1x SeeTheFuture")) {
				Inventory.remove(item);
				break;
			}				
		}
		// test only
//		System.out.println(this.showInventory());

	}
	
	
	public void ApplyPowerUp(String heroname, Product product) {
		for (Hero hero : TeamRoster) {
			if (hero.getHeroName().equals(heroname)){
				hero.ApplyPowerUp(product);
				break;
			}
		}			
	}
	
	
	
	
	public String getHeroInventory(String heroname, Product product) {
		
		for (Hero hero : TeamRoster) {
			if (hero.getHeroName().equals(heroname)){
				CurrentInventory =  hero.getHeroInventory();
				break;
			}
		}
		return CurrentInventory;			
	}
	
	public Hero getCurrentHero(int index) {
		return TeamRoster.get(index);
	}
	
	public boolean hasDice() {
		hasDice = false;
		for (Product product: Inventory) {
			if (product.getProductName().equals("1x Dice")) {
				hasDice = true;
			}
		}
		return hasDice;
	}

}
