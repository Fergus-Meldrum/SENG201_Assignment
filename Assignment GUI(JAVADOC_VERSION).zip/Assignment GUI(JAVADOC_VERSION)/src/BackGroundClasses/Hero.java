package BackGroundClasses;

import java.util.ArrayList;

/**
 * This is a Hero class
 * 
 * @author Fergus Meldrum, Chang Tu
 *
 */
public class Hero {

	private String HeroName;
	private String HeroType;
	private int Health = 100;
	private boolean healthFull;
	// changed array list to private from public
	private ArrayList<Product> Type_Inven = new ArrayList<Product>();
	private String Str_Inven = "";

	/**
	 * Set the name for hero
	 * 
	 * @param name
	 *            String
	 */
	public void setName(String name) {
		HeroName = name;
	}

	/**
	 * Get name form hero
	 * 
	 * @return HeroName String
	 */
	public String getHeroName() {
		return HeroName;
	}

	/**
	 * Set the type for hero
	 * 
	 * @param type
	 *            String
	 */
	public void setType(String type) {
		HeroType = type;
	}

	/**
	 * Get the type for hero
	 * 
	 * @return HeroType String
	 */
	public String getHeroType() {
		return HeroType;
	}

	/**
	 * Set the health for hero
	 * 
	 * @param damage
	 *            int
	 */
	public void setHealth(int damage) {
		this.Health -= damage;
		// remove hero from team if they die at some place
	}

	/**
	 * Get the health from hero
	 * 
	 * @return Health int
	 */
	public int getHealth() {
		return Health;
	}

	/**
	 * Boolean healthFull function, if health == 100, return true
	 * 
	 * @return healthFull boolean
	 */
	public boolean HealthOneHunnid() {
		healthFull = false;
		if (this.Health == 100) {
			healthFull = true;
		}
		return healthFull;
	}

	/**
	 * Increase the hero health, if health greater than or equal to 75, set to full
	 * else add a quater to hero health.
	 */
	public void gainHealth() {
		if (Health >= 75) {
			Health = 100;
		} else {
			Health += 25;
		}
	}

	/**
	 * A method that applies the power up to each hero
	 * 
	 * @param product
	 *            of type Product
	 */
	public void ApplyPowerUp(Product product) {
		Type_Inven.add(product);

	}

	/**
	 * Get inventory as a string, And return the String inventory
	 * 
	 * @return Str_Inventory as String
	 */
	public String getHeroInventory() {
		Str_Inven = "";
		for (Product powerUp : Type_Inven) {
			Str_Inven += powerUp.getProductName() + "\n";
		}
		// Str_Inven += Type_Inven.get(Type_Inven.size()-1).getProductName()+"\n";
		return Str_Inven;
	}

}
