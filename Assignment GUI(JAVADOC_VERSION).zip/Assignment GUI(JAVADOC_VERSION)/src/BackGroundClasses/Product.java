package BackGroundClasses;

/**
 * This is a main method product class
 * 
 * @author Fergus Meldrum, Chang Tu
 *
 */
public class Product {
	private int productCost;
	private String productName;

	/**
	 * Constructor of product class
	 * 
	 * @param name
	 *            String
	 * @param cost
	 *            int
	 */
	public Product(String name, int cost) {
		productCost = cost;
		productName = name;
	}

	/**
	 * This method returns the cost for each product
	 * 
	 * @return productCost int
	 */
	public int getProductCost() {
		return productCost;
	}

	/**
	 * This method set the product cost for different product
	 * 
	 * @param cost
	 *            int
	 */
	public void setProductCost(int cost) {
		productCost = cost;
	}

	/**
	 * This method get product name returns a product name String
	 * 
	 * @return productName String
	 */
	public String getProductName() {
		return productName;
	}

	/**
	 * This method is to set the product name
	 * 
	 * @param name
	 *            String
	 */
	public void setProductName(String name) {
		productName = name;
	}

}
