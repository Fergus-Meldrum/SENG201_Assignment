package BackGroundClasses;

import java.util.ArrayList;
import java.util.Random;

/**
 * This is the main class for team
 * 
 * @author Fergus Meldrum, Chang Tu
 *
 */
public class TeamGUI {

	private String teamName;
	private int NumHeros;
	private ArrayList<Hero> TeamRoster = new ArrayList<Hero>();
	private ArrayList<Product> Inventory = new ArrayList<Product>();
	private String inventory_string;
	private ArrayList<String> HeroNames = new ArrayList<String>();
	private Random random = new Random();
	private int randomIndex;
	private Product removedItem;
	private String currentMapName;
	private boolean hasMap = false;
	private int coin = 1000;
	private boolean sameName;
	private boolean nameFine;
	private int stringLength;
	private int numHealingItems;
	private int removeIndex;
	private String CurrentInventory = "None";

	/**
	 * This method is to set a team name for the team
	 * 
	 * @param name
	 *            String
	 */
	public void setTeamName(String name) {
		teamName = name;
	}

	/**
	 * This method is to get team name from the team
	 * 
	 * @return teamName String
	 */
	public String getTeamName() {
		return teamName;
	}

	/**
	 * This method is to set the hero number
	 * 
	 * @param number
	 *            int
	 */
	public void setNumHeros(int number) {
		NumHeros = number;
	}

	/**
	 * This method is to get the number of heroes
	 * 
	 * @return NumHeros int
	 */
	public int getNumHeros() {
		return NumHeros;
	}

	/**
	 * This method add hero to team roaster list
	 * 
	 * @param hero
	 *            typed Hero
	 */
	public void addHero(Hero hero) {
		TeamRoster.add(hero);
	}

	/**
	 * This method returns a String that contains items in the inventory
	 * 
	 * @return inventory_string String
	 */
	public String showInventory() {
		inventory_string = "";
		if (Inventory.isEmpty()) {
			inventory_string = "You Have no items in Inventory";
		} else {
			for (Product item : Inventory) {
				inventory_string += item.getProductName() + "\n";
			}
		}
		return inventory_string;
	}

	/**
	 * This method remove a random item when the team has been robbed
	 * 
	 * @return item name as a String
	 */
	public String removeRandomItem() {
		randomIndex = random.nextInt(Inventory.size());
		removedItem = Inventory.remove(randomIndex);
		return removedItem.getProductName();

	}

	/**
	 * This method add the product to the inventory
	 * 
	 * @param product
	 *            Product
	 */
	public void addInventory(Product product) {
		Inventory.add(product);
	}

	/**
	 * Return inventory items as a type: array list
	 * 
	 * @return Inventory as an ArrayList
	 */
	public ArrayList<Product> getInventory() {
		return this.Inventory;
	}

	/**
	 * Returns the heroes in the team
	 * 
	 * @return HeroNames as an ArrayList
	 */
	public ArrayList<String> getTeamNames() {
		for (Hero hero : TeamRoster) {
			HeroNames.add(hero.getHeroName());
		}
		return HeroNames;
	}

	/**
	 * Returns a boolean that have the map or not
	 * 
	 * @param currentCityNum
	 *            int
	 * @return hasMap boolean
	 */
	public boolean hasMap(int currentCityNum) {
		currentMapName = "1x Map of City " + currentCityNum;
		for (Product product : Inventory) {
			while (hasMap == false) {
				if ((product.getProductName()).equals(currentMapName)) {
					hasMap = true;
				}
			}
		}
		return hasMap;

	}

	/**
	 * Set the current coin
	 * 
	 * @param cost
	 *            int
	 */
	public void setCoin(int cost) {
		coin -= cost;
	}

	/**
	 * Get the current coin
	 * 
	 * @return
	 */
	public int getCoin() {
		return coin;
	}

	/**
	 * Hero cannot have same name with each other
	 * 
	 * @param name
	 *            String
	 * @return sameName boolean
	 */
	public boolean sameName(String name) {
		sameName = false;
		for (Hero hero : TeamRoster) {
			if (hero.getHeroName().equals(name)) {
				sameName = true;
			}
		}
		return sameName;
	}

	/**
	 * Returns the proper input name as a boolean
	 * 
	 * @param name
	 *            String
	 * @return nameFine boolean
	 */
	public boolean nameFine(String name) {
		nameFine = true;
		stringLength = name.length();
		if (stringLength < 2 || stringLength > 10) {
			nameFine = false;
		}
		return nameFine;
	}

	/**
	 * This method is to get the current hero
	 * 
	 * @param index
	 *            int
	 * @return hero Hero
	 */
	public Hero getCurrentHero(int index) {
		return TeamRoster.get(index);
	}

	/**
	 * This method is to remove a healing item from the inventory
	 */
	public void removeHealing() {
		for (int i = 0; i < (Inventory.size()); i++) {
			if (Inventory.get(i).getProductName().equals("Healing")) {
				removeIndex = i;
			}
		}
		Inventory.remove(removeIndex);
	}

	/**
	 * This method returns the number of healings in the inventory
	 * 
	 * @return numHealingItems int
	 */
	public int getNumHealings() {
		numHealingItems = 0;
		for (Product product : Inventory) {
			if (product.getProductName().equals("Healing")) {
				numHealingItems += 1;
			}
		}
		return numHealingItems;
	}

	/**
	 * This method to remove the dice product in the team inventory
	 */
	public void removeDice() {
		System.out.println(this.showInventory());
		for (Product item : Inventory) {
			if (item.getProductName().equals("1x Dice")) {
				Inventory.remove(item);
				break;
			}

		}
	}

	/**
	 * This method assigned two parametres and to apply the power up
	 * 
	 * @param heroname
	 *            String
	 * @param product
	 *            Product
	 */
	public void ApplyPowerUp(String heroname, Product product) {
		for (Hero hero : TeamRoster) {
			if (hero.getHeroName().equals(heroname)) {
				hero.ApplyPowerUp(product);
				break;
			}
		}
	}

	/**
	 * This method returns the hero inventory as a string
	 * 
	 * @param heroname
	 *            String
	 * @param product
	 *            Product
	 * @return CurrentInventory String
	 */
	public String getHeroInventory(String heroname, Product product) {

		for (Hero hero : TeamRoster) {
			if (hero.getHeroName().equals(heroname)) {
				CurrentInventory = hero.getHeroInventory();
				break;
			}
		}
		return CurrentInventory;
	}

	/**
	 * This method removes the guess products in the inventory
	 */
	public void removeGuess() {
		System.out.println(this.showInventory());
		for (Product item : Inventory) {
			if (item.getProductName().equals("1x Guess")) {
				Inventory.remove(item);
				break;
			}
		}
		// test only
		// System.out.println(this.showInventory());

	}

	/**
	 * This method removes the SeeTheFuture products in the inventory
	 */
	public void removeSeeTheFuture() {
		System.out.println(this.showInventory());
		for (Product item : Inventory) {
			if (item.getProductName().equals("1x SeeTheFuture")) {
				Inventory.remove(item);
				break;
			}
		}
		// test only
		// System.out.println(this.showInventory());

	}

}
