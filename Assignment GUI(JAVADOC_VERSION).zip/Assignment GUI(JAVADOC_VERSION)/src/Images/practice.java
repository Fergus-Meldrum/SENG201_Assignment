package Images;
import java.util.Random;

public class practice {
	
	private int  number;
	private Random randomNumber = new Random();
	
	public int randomNumber() {
		number = randomNumber.nextInt(3);
		return number;
	}
	
	public static void main(String[] args) {
		practice yo = new practice();
		System.out.println(yo.randomNumber());
	}

}
