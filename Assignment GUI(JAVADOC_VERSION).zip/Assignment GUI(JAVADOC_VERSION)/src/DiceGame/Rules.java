package DiceGame;

/**
 * Rules class
 * 
 * @author Fergus Meldrum, Chang Tu
 *
 */
public class Rules {
	// set villain dice remain 1, change hero dice number
	// to increase the change of possibility that hero won.
	// example figure shown as in the file uploaded
	// Change the hero dice roll chance for heroes to apply the dice power ups

	private int heroDice = 1;
	private int nTurns = 1;
	private int nSides = 6;

	/**
	 * Constructor of the Rules class,
	 * 
	 * @param s
	 *            int
	 * @param t
	 *            int
	 * @param d
	 *            int
	 */
	public Rules(int s, int t, int d) {
		nTurns = t;
		nSides = s;
		heroDice = d;
	}

	// constructor
	/**
	 * Constructor of the Rules class,
	 */
	public Rules() {
	}

	/**
	 * Set the dice number for hero
	 * 
	 * @param number
	 *            int
	 */
	public void setHeroDice(int number) {
		heroDice = number;
	}

	/**
	 * Get Sides as an integer for the game
	 * 
	 * @return nSides int
	 */
	public int getSides() {
		return nSides;
	}

	/**
	 * Get turns as an integer for the game
	 * 
	 * @return nTurns int
	 */
	public int getTurns() {
		return nTurns;
	}

	/**
	 * Gets the hero dice number
	 * 
	 * @return heroDice int
	 */
	public int getHeroDice() {
		return heroDice;

	}

	/**
	 * Villain dice remains 1, we could change the dice number for improve the game
	 * 
	 * @return 1 int
	 */
	public int getVillainDice() {
		return 1;

	}

}
