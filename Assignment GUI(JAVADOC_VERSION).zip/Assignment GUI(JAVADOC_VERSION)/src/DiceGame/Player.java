package DiceGame;

import java.util.Arrays;

/**
 * Two Player in this class: villain and hero.
 * 
 * @author Fergus Meldrum, Chang Tu
 *
 */
public class Player {
	private Rules rules;
	private int[][] turns;
	private int index;
	@SuppressWarnings("unused")
	private int turnScore;
	private int score = 0;
	private int pNumber;
	private static int players = 0;

	/**
	 * Constructor of the player class, hero dice first, then villain dice
	 * 
	 * @param r
	 *            Rules
	 */
	public Player(Rules r) {
		rules = r;
		pNumber = players + 1;

		if (pNumber == 1) {
			turns = new int[rules.getTurns()][rules.getHeroDice()];
		} else {
			turns = new int[rules.getTurns()][rules.getVillainDice()];
		}
		players++;
	}

	/**
	 * When hero play the dice game, update the score by the generated random dice
	 * roll
	 * 
	 * @param turn
	 *            int
	 */
	public void heroplay(int turn) {

		for (int n = 1; n <= rules.getHeroDice(); n++) {
			int value = Dice.roll(rules.getSides());
			turns[turn - 1][n - 1] = value;
		}
		updateHeroScore(turn);

	}

	/**
	 * When villain play the dice game, update the score by the generated random
	 * dice roll
	 * 
	 * @param turn
	 *            int
	 */
	public void villainplay(int turn) {

		for (int n = 1; n <= rules.getVillainDice(); n++) {
			int value = Dice.roll(rules.getSides());
			turns[turn - 1][n - 1] = value;
		}
		updateVillainScore(turn);

	}

	/**
	 * Update the final score for hero
	 * 
	 * @param turn
	 *            int
	 */
	private void updateHeroScore(int turn) {
		int[][] temp = turns;
		Arrays.sort(temp[turn - 1]);
		int max = temp[turn - 1][rules.getHeroDice() - 1];
		turnScore = max;
		score += max;
	}

	/**
	 * Update the final score for villain
	 * 
	 * @param turn
	 *            int
	 */
	private void updateVillainScore(int turn) {
		int[][] temp = turns;
		Arrays.sort(temp[turn - 1]);
		int max = temp[turn - 1][rules.getVillainDice() - 1];
		turnScore = max;
		score += max;
	}

	/**
	 * Construction of a two dimentional array getTurns which encounter the dice for
	 * each turn
	 * 
	 * @return turns int[][]
	 */
	public int[][] getTurns() {
		return turns;
	}

	/**
	 * Get score method, return an integer score
	 * 
	 * @return score int
	 */
	public int getScore() {
		return score;
	}

	/**
	 * Get index method, returns the current index
	 * 
	 * @return score as an int
	 */
	public int getIndex() {
		return index;
	}

	/**
	 * The method toString shows the result of dice game
	 */
	public String toString() {
		if (pNumber == 1) {
			return "Hero Results:";
		} else if (pNumber == 2) {
			return "Villain Results:";
		} else {
			String str = "Player " + pNumber + " Results:";
			return str;
		}
	}

}
