package DiceGame;

import java.util.Random;

/**
 * This is the dice class which generate the random Number for each dice roll
 * 
 * @author Fergus Meldrum, Chang Tu
 *
 */
public class Dice {
	/**
	 * Generate random number for each dice roll
	 * 
	 * @param num
	 *            int
	 * @return result int
	 */
	public static int roll(int num) {
		Random gen = new Random();
		int result = gen.nextInt(num) + 1;
		return result;

	}

}
